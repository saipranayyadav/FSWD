# AgroSense — Full-stack Greenhouse Monitoring

Real-time greenhouse dashboard built with **React**, **Node.js + Express**, and a **PostgreSQL / TimescaleDB** SQL database.
It was designed to cover all six course outcomes (CO1–CO6) — see [`docs/CO_MAPPING.md`](docs/CO_MAPPING.md) for the exact files.

```
Sensors / simulator ──MQTT──▶ Express ──SQL──▶ PostgreSQL (TimescaleDB)
                               │  ├─ REST API  (JWT auth, validation, rate limit)
                               │  ├─ Socket.IO (live telemetry)  ──▶ React dashboard (Recharts)
                               │  └─ SSE       (live alerts)     ──▶
```

## Quick start (no database install needed)

Requires **Node.js 18+** (https://nodejs.org).

**Windows:** double-click `RUN-AGROSENSE-WINDOWS.bat`
**macOS / Linux:** `./run.sh`
**Manual (two terminals):**
```bash
cd server && cp .env.example .env && npm install && npm run dev     # API on :4000
cd client && npm install && npm run dev                              # web on :5173
```
Open **http://localhost:5173**. The main page has **Login** and **Register** (username, email, password; stored in the PostgreSQL `users` table with bcrypt-hashed passwords).
Demo admin: username `admin` / password `admin123` (change in `server/.env`). Newly registered users are read-only viewers.

With an empty `DATABASE_URL` the server uses **PGlite** — a real PostgreSQL engine embedded in Node — and stores data in `server/data/`.
The simulator back-fills 24 h of history on the first start, then streams a new reading per zone every 3 s.

## Use a real PostgreSQL / TimescaleDB
```bash
docker compose -f infra/docker-compose.yml up --build      # db + mqtt broker + app on :4000
```
or set `DATABASE_URL=postgres://user:pass@host:5432/agrosense` in `server/.env`.
`db/schema.sql` runs automatically and turns `readings` into a TimescaleDB hypertable when the extension is available.

## Tests
```bash
cd server && npm test            # validation, alert rules, insights, plus full API integration tests
cd client && npm run typecheck   # TypeScript modules (api client, reducer, helpers)
```

## Connect real hardware (optional)
Flash `firmware/agrosense_node.ino` to an ESP32, point it at an MQTT broker, and set `MQTT_URL` in `server/.env`.
Devices can also POST JSON to `/api/readings` with header `x-api-key: <DEVICE_API_KEY>`.

## Deploy
* **Render** (API + React + PostgreSQL in one service): New → Blueprint → select this repo (`render.yaml`).
* **Vercel** (client only): root `client/`, env `VITE_API_URL=https://<your-render-url>`; set `CORS_ORIGIN` on the API to the Vercel URL.

## Project layout
```
server/   Express API · db/schema.sql · routes · middleware · realtime (Socket.IO, SSE, MQTT, simulator) · tests
client/   React (Vite) · pages · Context+useReducer state · Recharts · TypeScript lib/ · public/fundamentals.html
infra/    docker-compose (TimescaleDB + Mosquitto + app)
docs/     CO mapping, API reference, AI workflow
firmware/ ESP32 sketch
```
