# Course Outcome → Code Map

| CO | Where to look | What it demonstrates |
|----|---------------|----------------------|
| **CO1** HTML/CSS | `client/public/fundamentals.html`, `fundamentals.css`; `client/src/styles.css`; `components/Layout.jsx` | Semantic landmarks (`header/nav/main/aside/section/article/footer`), skip link, ARIA (`role="meter"`, `aria-live`, `aria-invalid`), table `caption/scope`, labelled forms, **CSS Grid** (app shell, `auto-fit/minmax` card grids), **Flexbox** (toolbars, rows), responsive breakpoints, CSS variables, dark mode, reduced-motion |
| **CO2** JS / TS | `client/public/fundamentals.js`; `client/src/lib/*.ts`; `server/src/**` | DOM manipulation without a framework; the same request as **callback (XHR), promise (`.then`) and `async/await`**; typed API client, reducer and helpers in **TypeScript**; ES modules, destructuring, closures, error handling |
| **CO3** React | `client/src/App.jsx`, `pages/*`, `components/*`, `context/AppContext.jsx`, `hooks/*` | JSX components, **hooks** (`useState/useEffect/useMemo/useReducer/useCallback/useId`, custom `useAsync`, `useRealtime`), **state management** with Context + reducer (`lib/reducer.ts`), React Router with protected routes, **Recharts** time-series (`LiveChart.jsx`, `pages/Climate.jsx`) |
| **CO4** Node + Express | `server/src/app.js`, `routes/*`, `middleware/*` | REST design (resources, verbs, status codes 200/201/204/400/401/403/404/409/429), **middleware chain** (CORS, JSON, logger, rate-limit, JWT auth, role check, validation, 404, central error handler), request/response handling, pagination headers (`X-Total-Count`) |
| **CO5** Real-time | `server/src/realtime/*`, `routes/alerts.js` (SSE), `client/src/hooks/useRealtime.js` | **WebSockets** via Socket.IO (telemetry, relay state, JWT-authenticated handshake), **Server-Sent Events** (alert feed with auto-reconnect), **MQTT → web bridge** (`mqtt.js`) and a built-in simulator when no broker exists |
| **CO6** DB, deploy, workflow | `server/db/schema.sql`, `server/src/db/*`, `Dockerfile`, `render.yaml`, `client/vercel.json`, `.github/workflows/ci.yml`, `docs/AI_WORKFLOW.md`, `services/insights.js` | **PostgreSQL + TimescaleDB** hypertable, relational tables with FKs/CHECKs, view, indexes, parameterised queries, time-bucket + aggregate + JOIN queries; Docker/Render/Vercel deployment; tests + CI; **AI-augmented** development workflow and an AI insights endpoint (Claude API, with rule-based fallback) |

## Suggested demo script (5 minutes)
1. Open `/fundamentals.html` — show semantic HTML, resize for responsive grid, click the three async buttons (CO1, CO2).
2. Sign in to the dashboard; point out live values and the chart updating without refresh (CO3, CO5).
3. **Sensor input** → enter soil `10` → alert appears instantly via SSE; irrigation auto-starts (CO5, CO4).
4. **Climate** → switch 1h / 24h / 7d: each is a SQL time-bucket query (CO6).
5. Show `GET /api/zones` without a token → 401; with a viewer token on `POST /api/irrigation/A` → 403 (CO4).
6. Show `docs/AI_WORKFLOW.md` and the **AI insights** page (CO6).
