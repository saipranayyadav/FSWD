# AI-augmented Full-stack Development (CO6)

AI assistants (Claude, Copilot, etc.) were used as a **pair programmer, not an autopilot**. This file records the method so it can be shown and defended.

## 1. Where AI helped
| Task | How it was used | Human check |
|------|-----------------|-------------|
| Scaffolding | Generate Express route/middleware skeletons and React page shells | Read every line; rename to project vocabulary |
| SQL | Draft the schema, `DISTINCT ON` view, time-bucket query | Run `EXPLAIN`, confirm parameters ($1…) — never string-concatenated |
| Tests | Propose edge cases (out-of-range readings, bad API key, viewer role) | Tests must fail when the code is broken (mutate and re-run) |
| Debugging | Paste error + minimal code, ask for hypotheses | Reproduce first, then fix the root cause |
| Docs | Draft README / API tables | Verify against the running API |

## 2. Prompt patterns that worked
* **Constrain the stack:** "Express 4, ES modules, no extra dependencies, PostgreSQL parameterised queries only."
* **Give the contract first:** paste the JSON shape the React page expects, then ask for the endpoint.
* **Ask for tests with the code:** "Write the handler and a `node:test` test for 400/401/403."
* **Ask for the failure modes:** "What can go wrong with this SSE endpoint behind a proxy?" (→ `X-Accel-Buffering`, heartbeat pings).

## 3. Review checklist before accepting AI code
- [ ] Do I understand every line well enough to explain it in a viva?
- [ ] Inputs validated? Auth and role checks present? Secrets in `.env`, not in code?
- [ ] Errors handled (async handlers wrapped, UI shows a message)?
- [ ] Accessibility: labels, focus, keyboard, contrast?
- [ ] Tests run green; no new dependency without a reason.

## 4. AI inside the product
`GET /api/insights` sends only **aggregated statistics** (no personal data) to the Claude API and asks for a ≤ 90-word briefing grounded in those numbers.
If no key is set, or the call fails, the endpoint falls back to deterministic rules (`server/src/services/insights.js`), so the feature degrades gracefully.
Configure with `ANTHROPIC_API_KEY` and `ANTHROPIC_MODEL` in `server/.env`.

## 5. Limits to remember
AI output can be confidently wrong, may use outdated library APIs, and never knows your grading rubric. Always run it, test it, and cite where AI assisted.
