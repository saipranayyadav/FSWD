# REST API

Base URL `http://localhost:4000`. JSON everywhere. Protected routes need `Authorization: Bearer <token>`.

| Method | Path | Auth | Description |
|--------|------|------|-------------|
| GET | `/api/health` | – | Status, uptime, database kind |
| GET | `/api/public/summary` | – | Averages + latest soil per crop (used by `fundamentals.html`) |
| POST | `/api/auth/register` | – | `{username,email,password}` → `201 {token,user}` (viewer role); `409` with `details` if the username/email exists |
| POST | `/api/auth/login` | – | `{username,password}` (username or email accepted) → `{token,user}` |
| GET | `/api/auth/me` | JWT | Current user |
| GET | `/api/zones` | JWT | Zones with relay state and latest reading |
| POST | `/api/zones` | admin | `{id,name,crop,dry?,wet?}` → 201 / 409 if the id exists |
| GET/PATCH/DELETE | `/api/zones/:id` | JWT / admin / admin | Read, update thresholds/name, delete (cascades readings) |
| GET | `/api/zones/:id/readings?limit=50` | JWT | Raw recent readings |
| POST | `/api/readings` | admin JWT **or** `x-api-key` | `{zone,soil,temp,humidity,light}` → stores, broadcasts, evaluates rules |
| GET | `/api/history?zone=all&hours=6&bucket=5` | JWT | Time-bucketed averages (minutes per bucket) |
| GET | `/api/stats?hours=24` | JWT | min/avg/max per zone (SQL aggregates) |
| GET | `/api/alerts?limit&offset&unacknowledged` | JWT | `{items,total}` + `X-Total-Count` |
| GET | `/api/alerts/stream?token=` | JWT | **SSE** stream of new alerts |
| POST | `/api/alerts/:id/ack`, `/api/alerts/ack-all` | admin | Acknowledge |
| POST | `/api/irrigation/:zone` | admin | `{on?: bool, auto?: bool}` |
| GET | `/api/irrigation/events` | JWT | Start/stop log (JOIN with users) |
| GET | `/api/insights` | JWT | Rule-based advice (+ Claude briefing when `ANTHROPIC_API_KEY` is set) |

**WebSocket (Socket.IO)** — connect with `auth: { token }`. Server emits `telemetry` (a reading) and `relay` (`{A:{on,auto},…}`).
**MQTT** — device publishes `agrosense/<zone>/telemetry` `{soil,temp,humidity,light}`; server publishes retained `agrosense/<zone>/irrigation` `{on}`.

Error shape: `{ "error": "message", "details": { "field": "reason" } }`.
