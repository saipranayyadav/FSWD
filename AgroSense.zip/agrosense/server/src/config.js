import 'dotenv/config';

const list = (v) => (v ? v.split(',').map((s) => s.trim()).filter(Boolean) : []);

export const config = {
  port: Number(process.env.PORT) || 4000,
  corsOrigin: list(process.env.CORS_ORIGIN).length ? list(process.env.CORS_ORIGIN) : true,
  databaseUrl: process.env.DATABASE_URL || '',
  pgSsl: process.env.PGSSL === 'true',
  jwtSecret: process.env.JWT_SECRET || 'dev-secret-change-me',
  adminUsername: process.env.ADMIN_USERNAME || 'admin',
  adminEmail: process.env.ADMIN_EMAIL || 'admin@agrosense.local',
  adminPassword: process.env.ADMIN_PASSWORD || 'admin123',
  deviceKey: process.env.DEVICE_API_KEY || 'device-demo-key',
  mqtt: { url: process.env.MQTT_URL || '', username: process.env.MQTT_USERNAME, password: process.env.MQTT_PASSWORD },
  anthropicKey: process.env.ANTHROPIC_API_KEY || '',
  anthropicModel: process.env.ANTHROPIC_MODEL || 'claude-sonnet-5-5',
  // set DB_MEMORY=true for tests: embedded PostgreSQL held in RAM
  dbMemory: process.env.DB_MEMORY === 'true',
};
