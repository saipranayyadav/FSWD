import http from 'http';
import { config } from './config.js';
import { initDb, dbKind } from './db/index.js';
import { createApp } from './app.js';
import { attachSocket } from './realtime/socket.js';
import { connectMqtt } from './realtime/mqtt.js';
import { startSimulator } from './realtime/simulator.js';
import { loadLatest } from './services/ingest.js';
import { seed } from './services/seed.js';

async function main() {
  console.log(`[db] connected (${await initDb()})`);
  await seed();
  await loadLatest();

  const server = http.createServer(createApp());
  attachSocket(server);
  if (!connectMqtt()) await startSimulator();

  server.listen(config.port, () => console.log(`AgroSense API listening on :${config.port} (database: ${dbKind()})`));
}

main().catch((e) => { console.error('Fatal startup error:', e); process.exit(1); });
