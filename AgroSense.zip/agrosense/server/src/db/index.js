// Database access layer. Both back-ends speak PostgreSQL:
//   * DATABASE_URL set -> node-postgres pool (PostgreSQL / TimescaleDB)
//   * otherwise        -> PGlite, an embedded PostgreSQL that needs no install
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { config } from '../config.js';

const here = path.dirname(fileURLToPath(import.meta.url));
let backend = null;
let kind = 'none';

export async function initDb() {
  const schema = fs.readFileSync(path.join(here, '../../db/schema.sql'), 'utf8');
  if (config.databaseUrl) {
    const pg = (await import('pg')).default;
    const pool = new pg.Pool({
      connectionString: config.databaseUrl,
      ssl: config.pgSsl ? { rejectUnauthorized: false } : undefined,
    });
    backend = { query: (sql, params) => pool.query(sql, params), exec: (sql) => pool.query(sql), close: () => pool.end() };
    kind = 'postgres';
  } else {
    const { PGlite } = await import('@electric-sql/pglite');
    const dir = config.dbMemory ? undefined : path.resolve(here, '../../data/agrosense');
    if (dir) fs.mkdirSync(path.dirname(dir), { recursive: true });
    const db = new PGlite(dir);
    await db.waitReady;
    backend = { query: (sql, params) => db.query(sql, params), exec: (sql) => db.exec(sql), close: () => db.close() };
    kind = config.dbMemory ? 'pglite-memory' : 'pglite';
  }
  await backend.exec(schema);
  return kind;
}

export const dbKind = () => kind;

/** Run a parameterised SQL statement. Always use $1, $2 placeholders - never string concatenation. */
export async function query(sql, params = []) {
  if (!backend) throw new Error('Database not initialised');
  const res = await backend.query(sql, params);
  return res.rows;
}

export const closeDb = () => backend?.close();
