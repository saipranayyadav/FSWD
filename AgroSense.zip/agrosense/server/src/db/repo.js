// All SQL lives here so routes and services stay free of query strings.
import { query } from './index.js';

const r1 = (n) => Math.round(Number(n) * 10) / 10;
const zoneOut = (z) => ({
  id: z.id, name: z.name, crop: z.crop,
  dry: z.dry_threshold, wet: z.wet_threshold,
  relay: { on: z.relay_on, auto: z.auto_mode },
});

// ---------- users ----------
export const users = {
  /** Login accepts the username or the email address (case-insensitive). */
  byLogin: async (login) =>
    (await query('SELECT * FROM users WHERE lower(username) = lower($1) OR email = lower($1)', [login]))[0],
  byUsername: async (username) => (await query('SELECT id FROM users WHERE lower(username) = lower($1)', [username]))[0],
  byEmail: async (email) => (await query('SELECT id FROM users WHERE email = lower($1)', [email]))[0],
  byId: async (id) => (await query('SELECT id, username, email, name, role FROM users WHERE id = $1', [id]))[0],
  create: async ({ username, email, passwordHash, role = 'viewer' }) =>
    (await query(
      'INSERT INTO users (username, email, name, password_hash, role) VALUES ($1, lower($2), $1, $3, $4) RETURNING id, username, email, name, role',
      [username, email, passwordHash, role]
    ))[0],
  count: async () => Number((await query('SELECT count(*) AS n FROM users'))[0].n),
};

// ---------- zones ----------
export const zones = {
  async list() {
    return (await query('SELECT * FROM zones ORDER BY id')).map(zoneOut);
  },
  async get(id) {
    const z = (await query('SELECT * FROM zones WHERE id = $1', [id]))[0];
    return z ? zoneOut(z) : null;
  },
  async create({ id, name, crop, dry = 30, wet = 62 }) {
    const z = (await query(
      'INSERT INTO zones (id, name, crop, dry_threshold, wet_threshold) VALUES ($1, $2, $3, $4, $5) RETURNING *',
      [id, name, crop, dry, wet]
    ))[0];
    return zoneOut(z);
  },
  async update(id, patch) {
    const z = (await query(
      `UPDATE zones SET name = COALESCE($2, name), crop = COALESCE($3, crop),
              dry_threshold = COALESCE($4, dry_threshold), wet_threshold = COALESCE($5, wet_threshold)
        WHERE id = $1 RETURNING *`,
      [id, patch.name ?? null, patch.crop ?? null, patch.dry ?? null, patch.wet ?? null]
    ))[0];
    return z ? zoneOut(z) : null;
  },
  async remove(id) {
    return (await query('DELETE FROM zones WHERE id = $1 RETURNING id', [id])).length > 0;
  },
  async setRelay(id, on, auto) {
    const z = (await query(
      'UPDATE zones SET relay_on = $2, auto_mode = $3 WHERE id = $1 RETURNING *', [id, on, auto]
    ))[0];
    return z ? zoneOut(z) : null;
  },
  async count() {
    return Number((await query('SELECT count(*) AS n FROM zones'))[0].n);
  },
};

// ---------- readings (time-series) ----------
const readingOut = (x) => ({
  time: new Date(x.time).getTime(), zone: x.zone_id,
  soil: r1(x.soil_moisture), temp: r1(x.temperature), humidity: r1(x.humidity), light: Math.round(x.light),
});

export const readings = {
  async save(r) {
    await query(
      `INSERT INTO readings (time, zone_id, soil_moisture, temperature, humidity, light)
       VALUES (to_timestamp($1::double precision / 1000), $2, $3, $4, $5, $6)`,
      [r.time, r.zone, r.soil, r.temp, r.humidity, r.light]
    );
  },
  /** Bulk insert (used to back-fill history). Chunked so we stay under the parameter limit. */
  async saveMany(rows) {
    for (let i = 0; i < rows.length; i += 200) {
      const chunk = rows.slice(i, i + 200);
      const params = [];
      const values = chunk.map((r, j) => {
        params.push(r.time, r.zone, r.soil, r.temp, r.humidity, r.light);
        const b = j * 6;
        return `(to_timestamp($${b + 1}::double precision / 1000), $${b + 2}, $${b + 3}, $${b + 4}, $${b + 5}, $${b + 6})`;
      });
      await query(`INSERT INTO readings (time, zone_id, soil_moisture, temperature, humidity, light) VALUES ${values.join(',')}`, params);
    }
  },
  async isEmpty() {
    return (await query('SELECT 1 FROM readings LIMIT 1')).length === 0;
  },
  async latest() {
    return (await query('SELECT * FROM v_zone_latest ORDER BY zone_id')).map(readingOut);
  },
  async recent(zone, limit) {
    return (await query('SELECT * FROM readings WHERE zone_id = $1 ORDER BY time DESC LIMIT $2', [zone, limit])).map(readingOut);
  },
  /** Time-bucketed averages - the core time-series query behind the charts. */
  async history(zone, hours, bucketMinutes) {
    const rows = await query(
      `SELECT floor(extract(epoch FROM time) / $3) * $3 * 1000 AS t, zone_id,
              avg(soil_moisture) AS soil, avg(temperature) AS temp, avg(humidity) AS humidity, avg(light) AS light
         FROM readings
        WHERE time > now() - make_interval(hours => $2::int) AND ($1 = 'all' OR zone_id = $1)
        GROUP BY 1, 2
        ORDER BY 1`,
      [zone, hours, bucketMinutes * 60]
    );
    return rows.map((x) => ({ t: Number(x.t), zone: x.zone_id, soil: r1(x.soil), temp: r1(x.temp), humidity: r1(x.humidity), light: Math.round(x.light) }));
  },
  /** Aggregate statistics per zone over a window (min / avg / max). */
  async stats(hours) {
    const rows = await query(
      `SELECT z.id AS zone_id, z.name, z.crop, count(r.time) AS samples,
              avg(r.soil_moisture) AS soil_avg, min(r.soil_moisture) AS soil_min, max(r.soil_moisture) AS soil_max,
              avg(r.temperature) AS temp_avg, min(r.temperature) AS temp_min, max(r.temperature) AS temp_max,
              avg(r.humidity) AS hum_avg, avg(r.light) AS light_avg
         FROM zones z
         LEFT JOIN readings r ON r.zone_id = z.id AND r.time > now() - make_interval(hours => $1::int)
        GROUP BY z.id, z.name, z.crop
        ORDER BY z.id`,
      [hours]
    );
    return rows.map((x) => ({
      zone: x.zone_id, name: x.name, crop: x.crop, samples: Number(x.samples),
      soil: { avg: r1(x.soil_avg ?? 0), min: r1(x.soil_min ?? 0), max: r1(x.soil_max ?? 0) },
      temp: { avg: r1(x.temp_avg ?? 0), min: r1(x.temp_min ?? 0), max: r1(x.temp_max ?? 0) },
      humidity: r1(x.hum_avg ?? 0), light: Math.round(x.light_avg ?? 0),
    }));
  },
};

// ---------- alerts ----------
const alertOut = (a) => ({
  id: a.id, time: new Date(a.time).getTime(), zone: a.zone_id, level: a.level, message: a.message, acknowledged: a.acknowledged,
});

export const alerts = {
  async create({ time, zone, level, message }) {
    const a = (await query(
      `INSERT INTO alerts (time, zone_id, level, message)
       VALUES (to_timestamp($1::double precision / 1000), $2, $3, $4) RETURNING *`,
      [time, zone, level, message]
    ))[0];
    return alertOut(a);
  },
  async list({ limit, offset, unacknowledged }) {
    const flag = !!unacknowledged;
    const rows = await query(
      `SELECT * FROM alerts WHERE ($3::boolean = FALSE OR acknowledged = FALSE)
        ORDER BY time DESC LIMIT $1 OFFSET $2`,
      [limit, offset, flag]
    );
    const total = Number((await query('SELECT count(*) AS n FROM alerts WHERE ($1::boolean = FALSE OR acknowledged = FALSE)', [flag]))[0].n);
    return { items: rows.map(alertOut), total };
  },
  async acknowledge(id, userId) {
    const a = (await query('UPDATE alerts SET acknowledged = TRUE, acknowledged_by = $2 WHERE id = $1 RETURNING *', [id, userId]))[0];
    return a ? alertOut(a) : null;
  },
  async acknowledgeAll(userId) {
    return (await query('UPDATE alerts SET acknowledged = TRUE, acknowledged_by = $1 WHERE acknowledged = FALSE RETURNING id', [userId])).length;
  },
  async unacknowledgedCount() {
    return Number((await query('SELECT count(*) AS n FROM alerts WHERE acknowledged = FALSE'))[0].n);
  },
};

// ---------- irrigation log ----------
export const irrigation = {
  async log({ zone, action, source, userId = null }) {
    await query('INSERT INTO irrigation_events (zone_id, action, source, user_id) VALUES ($1, $2, $3, $4)', [zone, action, source, userId]);
  },
  async events(limit) {
    const rows = await query(
      `SELECT e.id, e.time, e.zone_id, e.action, e.source, u.name AS user_name
         FROM irrigation_events e LEFT JOIN users u ON u.id = e.user_id
        ORDER BY e.time DESC LIMIT $1`,
      [limit]
    );
    return rows.map((e) => ({ id: e.id, time: new Date(e.time).getTime(), zone: e.zone_id, action: e.action, source: e.source, user: e.user_name }));
  },
};
