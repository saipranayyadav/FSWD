import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import express from 'express';
import cors from 'cors';
import { config } from './config.js';
import { logger } from './middleware/logger.js';
import { rateLimit } from './middleware/rateLimit.js';
import { requireAuth } from './middleware/auth.js';
import { notFound, errorHandler } from './middleware/errors.js';
import publicRoutes from './routes/public.js';
import authRoutes from './routes/auth.js';
import zoneRoutes from './routes/zones.js';
import readingRoutes from './routes/readings.js';
import alertRoutes from './routes/alerts.js';
import irrigationRoutes from './routes/irrigation.js';
import insightRoutes from './routes/insights.js';
import analyticsRoutes from './routes/analytics.js';

export function createApp() {
  const app = express();
  app.set('trust proxy', 1); // correct client IPs behind Render / Vercel proxies

  // ---- middleware chain (order matters) ----
  app.use(cors({ origin: config.corsOrigin }));
  app.use(express.json({ limit: '50kb' }));
  app.use(logger);
  app.use('/api', rateLimit({ max: 300 }));
  app.use('/api/auth', rateLimit({ max: 20 })); // stricter limit against password guessing

  // ---- REST API ----
  app.use('/api', publicRoutes);
  app.use('/api/auth', authRoutes);
  app.use('/api/readings', readingRoutes); // POST only: admin JWT or device key
  app.use('/api', analyticsRoutes); // GET /history, /stats
  app.use('/api/alerts', alertRoutes);
  app.use('/api/zones', requireAuth, zoneRoutes);
  app.use('/api/irrigation', requireAuth, irrigationRoutes);
  app.use('/api/insights', requireAuth, insightRoutes);
  app.use('/api', (req, res) => res.status(404).json({ error: 'Not found' }));

  // ---- optionally serve the built React app from the same service (single-host deploys) ----
  const dist = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../../client/dist');
  if (fs.existsSync(dist)) {
    app.use(express.static(dist));
    app.get(/^(?!\/api|\/socket\.io).*/, (req, res) => res.sendFile(path.join(dist, 'index.html')));
  }

  app.use(notFound);
  app.use(errorHandler);
  return app;
}
