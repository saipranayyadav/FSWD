import { Router } from 'express';
import { zones, readings } from '../db/repo.js';
import { latest } from '../services/ingest.js';
import { requireRole } from '../middleware/auth.js';
import { validate } from '../middleware/validate.js';
import { asyncHandler, HttpError } from '../middleware/errors.js';

const router = Router();
const upper = (s) => s.toUpperCase();
const withLatest = (z) => ({ ...z, latest: latest[z.id] || null });

const name = { type: 'string', minLength: 2, maxLength: 60 };
const crop = { type: 'string', minLength: 2, maxLength: 40 };
const dry = { type: 'number', min: 0, max: 100 };
const wet = { type: 'number', min: 0, max: 100 };
const createSchema = {
  id: { type: 'string', required: true, pattern: /^[A-Za-z0-9_-]{1,12}$/, transform: upper },
  name: { ...name, required: true }, crop: { ...crop, required: true }, dry, wet,
};
const patchSchema = { name, crop, dry, wet };
const checkThresholds = (b) => {
  if (b.dry !== undefined && b.wet !== undefined && b.dry >= b.wet) throw new HttpError(400, 'dry threshold must be below wet threshold');
};

router.get('/', asyncHandler(async (req, res) => res.json((await zones.list()).map(withLatest))));

router.get('/:id', asyncHandler(async (req, res) => {
  const z = await zones.get(upper(req.params.id));
  if (!z) throw new HttpError(404, 'Zone not found');
  res.json(withLatest(z));
}));

router.get('/:id/readings', asyncHandler(async (req, res) => {
  const limit = Math.min(Math.max(Number(req.query.limit) || 50, 1), 500);
  const id = upper(req.params.id);
  if (!(await zones.get(id))) throw new HttpError(404, 'Zone not found');
  res.json(await readings.recent(id, limit));
}));

router.post('/', requireRole('admin'), validate(createSchema), asyncHandler(async (req, res) => {
  checkThresholds(req.body);
  res.status(201).json(withLatest(await zones.create(req.body)));
}));

router.patch('/:id', requireRole('admin'), validate(patchSchema), asyncHandler(async (req, res) => {
  checkThresholds(req.body);
  const z = await zones.update(upper(req.params.id), req.body);
  if (!z) throw new HttpError(404, 'Zone not found');
  res.json(withLatest(z));
}));

router.delete('/:id', requireRole('admin'), asyncHandler(async (req, res) => {
  const id = upper(req.params.id);
  if (!(await zones.remove(id))) throw new HttpError(404, 'Zone not found');
  delete latest[id];
  res.status(204).end();
}));

export default router;
