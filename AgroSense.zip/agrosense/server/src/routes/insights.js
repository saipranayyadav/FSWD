import { Router } from 'express';
import { readings, zones } from '../db/repo.js';
import { buildInsights } from '../services/insights.js';
import { asyncHandler } from '../middleware/errors.js';

const router = Router();

router.get('/', asyncHandler(async (req, res) => {
  const [stats, zoneList] = await Promise.all([readings.stats(24), zones.list()]);
  res.json(await buildInsights(stats, zoneList));
}));

export default router;
