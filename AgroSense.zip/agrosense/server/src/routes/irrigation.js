import { Router } from 'express';
import { irrigation } from '../db/repo.js';
import { setRelay } from '../services/ingest.js';
import { requireRole } from '../middleware/auth.js';
import { asyncHandler, HttpError } from '../middleware/errors.js';

const router = Router();

router.get('/events', asyncHandler(async (req, res) => {
  const limit = Math.min(Math.max(Number(req.query.limit) || 20, 1), 100);
  res.json(await irrigation.events(limit));
}));

router.post('/:zone', requireRole('admin'), asyncHandler(async (req, res) => {
  const { on, auto } = req.body || {};
  if (typeof on !== 'boolean' && typeof auto !== 'boolean') throw new HttpError(400, 'Send "on" and/or "auto" as boolean');
  const z = await setRelay(req.params.zone.toUpperCase(), { on, auto }, { source: 'manual', userId: req.user.id });
  if (!z) throw new HttpError(404, 'Unknown zone');
  res.json(z.relay);
}));

export default router;
