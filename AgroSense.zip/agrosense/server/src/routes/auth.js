import { Router } from 'express';
import bcrypt from 'bcryptjs';
import { users } from '../db/repo.js';
import { validate } from '../middleware/validate.js';
import { asyncHandler, HttpError } from '../middleware/errors.js';
import { requireAuth, signToken } from '../middleware/auth.js';

const router = Router();
const EMAIL = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const USERNAME = /^[A-Za-z0-9_.-]{3,30}$/;
const publicUser = (u) => ({ id: u.id, username: u.username, email: u.email, name: u.name, role: u.role });

// POST /api/auth/register  { username, email, password } -> 201 { token, user }
router.post('/register',
  validate({
    username: { type: 'string', required: true, pattern: USERNAME },
    email: { type: 'string', required: true, pattern: EMAIL, maxLength: 120 },
    password: { type: 'string', required: true, minLength: 6, maxLength: 100 },
  }),
  asyncHandler(async (req, res) => {
    const { username, email, password } = req.body;
    const taken = {};
    if (await users.byUsername(username)) taken.username = 'is already taken';
    if (await users.byEmail(email)) taken.email = 'is already registered';
    if (Object.keys(taken).length) throw new HttpError(409, 'Account already exists', taken);

    const user = await users.create({ username, email, passwordHash: await bcrypt.hash(password, 10) });
    res.status(201).json({ token: signToken(user), user: publicUser(user) });
  })
);

// POST /api/auth/login  { username, password } -> { token, user }   (username may also be the email)
router.post('/login',
  validate({
    username: { type: 'string', required: true, maxLength: 120 },
    password: { type: 'string', required: true },
  }),
  asyncHandler(async (req, res) => {
    const row = await users.byLogin(req.body.username);
    if (!row || !(await bcrypt.compare(req.body.password, row.password_hash))) throw new HttpError(401, 'Wrong username or password');
    res.json({ token: signToken(row), user: publicUser(row) });
  })
);

router.get('/me', requireAuth, asyncHandler(async (req, res) => {
  const user = await users.byId(req.user.id);
  if (!user) throw new HttpError(401, 'User no longer exists');
  res.json({ user: publicUser(user) });
}));

export default router;
