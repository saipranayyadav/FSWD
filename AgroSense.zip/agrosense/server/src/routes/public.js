import { Router } from 'express';
import { dbKind } from '../db/index.js';
import { zones } from '../db/repo.js';
import { latest } from '../services/ingest.js';
import { asyncHandler } from '../middleware/errors.js';

const router = Router();

router.get('/health', (req, res) => res.json({ status: 'ok', uptime: Math.round(process.uptime()), database: dbKind() }));

// Read-only, no-login summary used by the plain HTML/JS page (client/public/fundamentals.html)
router.get('/public/summary', asyncHandler(async (req, res) => {
  const list = await zones.list();
  const vals = list.map((z) => latest[z.id]).filter(Boolean);
  const avg = (k) => (vals.length ? Math.round((vals.reduce((s, v) => s + v[k], 0) / vals.length) * 10) / 10 : null);
  res.json({
    zones: list.length,
    average: { soil: avg('soil'), temp: avg('temp'), humidity: avg('humidity'), light: avg('light') },
    crops: list.map((z) => ({ id: z.id, crop: z.crop, soil: latest[z.id]?.soil ?? null })),
  });
}));

export default router;
