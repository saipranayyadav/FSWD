import { Router } from 'express';
import { alerts } from '../db/repo.js';
import { bus } from '../services/bus.js';
import { requireAuth, requireRole } from '../middleware/auth.js';
import { asyncHandler, HttpError } from '../middleware/errors.js';

const router = Router();

// ---- Server-Sent Events: one-way live alert feed (CO5) ----
const clients = new Set();
router.get('/stream', requireAuth, (req, res) => {
  res.set({ 'Content-Type': 'text/event-stream', 'Cache-Control': 'no-cache', Connection: 'keep-alive', 'X-Accel-Buffering': 'no' });
  res.flushHeaders();
  res.write('retry: 3000\n\n');
  clients.add(res);
  const ping = setInterval(() => res.write(': ping\n\n'), 25_000);
  req.on('close', () => { clearInterval(ping); clients.delete(res); });
});
bus.on('alert', (a) => clients.forEach((r) => r.write(`event: alert\ndata: ${JSON.stringify(a)}\n\n`)));

router.get('/', requireAuth, asyncHandler(async (req, res) => {
  const limit = Math.min(Math.max(Number(req.query.limit) || 30, 1), 200);
  const offset = Math.max(Number(req.query.offset) || 0, 0);
  const data = await alerts.list({ limit, offset, unacknowledged: req.query.unacknowledged === 'true' });
  res.set('X-Total-Count', String(data.total));
  res.json(data);
}));

router.post('/ack-all', requireAuth, requireRole('admin'), asyncHandler(async (req, res) => {
  res.json({ acknowledged: await alerts.acknowledgeAll(req.user.id) });
}));

router.post('/:id/ack', requireAuth, requireRole('admin'), asyncHandler(async (req, res) => {
  const id = Number(req.params.id);
  if (!Number.isInteger(id)) throw new HttpError(400, 'Alert id must be a number');
  const a = await alerts.acknowledge(id, req.user.id);
  if (!a) throw new HttpError(404, 'Alert not found');
  res.json(a);
}));

export default router;
