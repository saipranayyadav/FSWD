import { Router } from 'express';
import { readings } from '../db/repo.js';
import { requireAuth } from '../middleware/auth.js';
import { asyncHandler } from '../middleware/errors.js';

const router = Router();
const clampNum = (v, def, min, max) => Math.min(Math.max(Number(v) || def, min), max);

// GET /api/history?zone=all|A&hours=6&bucket=5  -> time-bucketed averages for charts
router.get('/history', requireAuth, asyncHandler(async (req, res) => {
  const zone = String(req.query.zone || 'all');
  res.json(await readings.history(zone.toLowerCase() === 'all' ? 'all' : zone.toUpperCase(), clampNum(req.query.hours, 6, 1, 168), clampNum(req.query.bucket, 5, 1, 240)));
}));

// GET /api/stats?hours=24 -> min / avg / max per zone (SQL aggregate + JOIN)
router.get('/stats', requireAuth, asyncHandler(async (req, res) => {
  res.json(await readings.stats(clampNum(req.query.hours, 24, 1, 168)));
}));

export default router;
