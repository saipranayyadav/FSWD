import { Router } from 'express';
import { ingest } from '../services/ingest.js';
import { adminOrDevice } from '../middleware/auth.js';
import { validate } from '../middleware/validate.js';
import { asyncHandler, HttpError } from '../middleware/errors.js';

const router = Router();

// Manual entry from the UI (admin JWT) or an HTTP-capable device (x-api-key header).
router.post('/',
  adminOrDevice,
  validate({
    zone: { type: 'string', required: true, transform: (s) => s.toUpperCase() },
    soil: { type: 'number', required: true, min: 0, max: 100 },
    temp: { type: 'number', required: true, min: -20, max: 70 },
    humidity: { type: 'number', required: true, min: 0, max: 100 },
    light: { type: 'number', required: true, min: 0, max: 150000 },
  }),
  asyncHandler(async (req, res) => {
    const result = await ingest(req.body);
    if (!result.ok) throw new HttpError(404, 'Zone not found');
    res.status(201).json(result.reading);
  })
);

export default router;
