// MQTT <-> web bridge (CO5).
//   device  -> agrosense/<zone>/telemetry   { soil, temp, humidity, light }   -> ingest -> WebSocket
//   server  -> agrosense/<zone>/irrigation  { on: true|false } (retained)     <- bus 'command'
import mqtt from 'mqtt';
import { config } from '../config.js';
import { bus } from '../services/bus.js';
import { ingest } from '../services/ingest.js';

export function connectMqtt() {
  if (!config.mqtt.url) return false;
  const client = mqtt.connect(config.mqtt.url, { username: config.mqtt.username, password: config.mqtt.password });
  client.on('connect', () => { console.log('[mqtt] connected'); client.subscribe('agrosense/+/telemetry'); });
  client.on('error', (e) => console.error('[mqtt]', e.message));
  client.on('message', async (topic, buf) => {
    try {
      const zone = topic.split('/')[1].toUpperCase();
      const d = JSON.parse(buf.toString());
      const nums = [d.soil, d.temp, d.humidity, d.light];
      if (nums.some((n) => typeof n !== 'number' || Number.isNaN(n))) throw new Error('payload needs numeric soil, temp, humidity, light');
      await ingest({ zone, soil: d.soil, temp: d.temp, humidity: d.humidity, light: d.light });
    } catch (e) { console.error('[mqtt] bad message:', e.message); }
  });
  bus.on('command', ({ zone, on }) => client.publish(`agrosense/${zone}/irrigation`, JSON.stringify({ on }), { retain: true }));
  return true;
}
