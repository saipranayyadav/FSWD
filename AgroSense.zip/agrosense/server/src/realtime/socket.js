// WebSocket layer (Socket.IO) - live telemetry + relay state pushed to every logged-in browser.
import { Server } from 'socket.io';
import { config } from '../config.js';
import { verifyToken } from '../middleware/auth.js';
import { bus } from '../services/bus.js';
import { latest, relayState } from '../services/ingest.js';

export function attachSocket(httpServer) {
  const io = new Server(httpServer, { cors: { origin: config.corsOrigin } });

  io.use((socket, next) => {
    try { socket.data.user = verifyToken(socket.handshake.auth?.token); next(); }
    catch { next(new Error('unauthorized')); }
  });

  io.on('connection', async (socket) => {
    socket.emit('relay', await relayState());
    Object.values(latest).forEach((r) => socket.emit('telemetry', r));
  });

  bus.on('telemetry', (r) => io.emit('telemetry', r));
  bus.on('relay', (state) => io.emit('relay', state));
  return io;
}
