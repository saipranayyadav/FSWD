// Greenhouse simulator: used when no MQTT broker is configured so the dashboard is alive out of the box.
import { zones, readings } from '../db/repo.js';
import { ingest } from '../services/ingest.js';

const rnd = (a, b) => a + Math.random() * (b - a);
const r1 = (n) => Math.round(n * 10) / 10;
const clamp = (n, a, b) => Math.min(b, Math.max(a, n));
const soil = {};

function climate(t, i) {
  const d = new Date(t);
  const h = d.getHours() + d.getMinutes() / 60;
  const day = Math.sin(((h - 9) / 24) * 2 * Math.PI);
  return {
    temp: r1(25 + i * 0.6 + 5 * day + rnd(-0.4, 0.4)),
    humidity: r1(clamp(66 - 14 * day + rnd(-1, 1), 30, 95)),
    light: Math.round(Math.max(0, 52000 * Math.sin(((h - 6) / 12) * Math.PI)) * rnd(0.92, 1)),
  };
}

async function backfill() {
  if (!(await readings.isEmpty())) return;
  const now = Date.now();
  const rows = [];
  for (const [i, z] of (await zones.list()).entries()) {
    let s = 58 + rnd(-4, 4);
    for (let t = now - 24 * 3600e3; t < now; t += 300e3) {
      s -= rnd(0.2, 0.9);
      if (s < z.dry - 3) s = rnd(58, 64);
      rows.push({ time: t, zone: z.id, soil: r1(s), ...climate(t, i) });
    }
  }
  await readings.saveMany(rows);
  console.log(`[sim] back-filled ${rows.length} historical readings`);
}

async function tick() {
  try {
    for (const [i, z] of (await zones.list()).entries()) {
      soil[z.id] ??= 52 + i * 5;
      soil[z.id] = clamp(soil[z.id] + (z.relay.on ? rnd(0.8, 1.6) : -rnd(0.03, 0.18)), 8, 85);
      await ingest({ zone: z.id, soil: r1(soil[z.id]), ...climate(Date.now(), i) });
    }
  } catch (e) { console.error('[sim] tick failed:', e.message); }
}

export async function startSimulator() {
  await backfill();
  console.log('[sim] greenhouse simulator running');
  setInterval(tick, 3000).unref();
  tick();
}
