import bcrypt from 'bcryptjs';
import { config } from '../config.js';
import { users, zones } from '../db/repo.js';

export async function seed() {
  if ((await users.count()) === 0) {
    await users.create({
      username: config.adminUsername, email: config.adminEmail, role: 'admin',
      passwordHash: await bcrypt.hash(config.adminPassword, 10),
    });
    console.log(`[seed] admin user created: ${config.adminUsername}`);
  }
  if ((await zones.count()) === 0) {
    await zones.create({ id: 'A', name: 'Zone A', crop: 'Tomato', dry: 32 });
    await zones.create({ id: 'B', name: 'Zone B', crop: 'Capsicum', dry: 30 });
    await zones.create({ id: 'C', name: 'Zone C', crop: 'Lettuce', dry: 38 });
    console.log('[seed] default zones created');
  }
}
