import { bus } from './bus.js';
import { evaluateReading, decideIrrigation } from './rules.js';
import { readings, zones, alerts, irrigation } from '../db/repo.js';

export const latest = {}; // zone id -> newest reading (memory cache for fast dashboards)
const lastAlert = {};
const ALERT_COOLDOWN_MS = 90_000;

export async function loadLatest() {
  for (const r of await readings.latest()) latest[r.zone] = r;
}

export async function relayState() {
  return Object.fromEntries((await zones.list()).map((z) => [z.id, z.relay]));
}

/** Change a relay, persist it, log the event, and tell every listener (WebSocket + MQTT). */
export async function setRelay(zoneId, { on, auto }, { source = 'manual', userId = null } = {}) {
  const current = await zones.get(zoneId);
  if (!current) return null;
  const nextOn = typeof on === 'boolean' ? on : current.relay.on;
  const nextAuto = typeof auto === 'boolean' ? auto : typeof on === 'boolean' && source === 'manual' ? false : current.relay.auto;
  const updated = await zones.setRelay(zoneId, nextOn, nextAuto);
  if (nextOn !== current.relay.on) {
    await irrigation.log({ zone: zoneId, action: nextOn ? 'start' : 'stop', source, userId });
    bus.emit('command', { zone: zoneId, on: nextOn });
  }
  bus.emit('relay', await relayState());
  return updated;
}

async function raise(zoneId, { key, level, message }) {
  const now = Date.now();
  if (now - (lastAlert[key] || 0) < ALERT_COOLDOWN_MS) return;
  lastAlert[key] = now;
  const alert = await alerts.create({ time: now, zone: zoneId, level, message });
  bus.emit('alert', alert);
}

/** Single entry point for every sensor reading: HTTP, MQTT or simulator. */
export async function ingest(input) {
  const r = { ...input, time: input.time ?? Date.now() };
  const zone = await zones.get(r.zone);
  if (!zone) return { ok: false, reason: 'unknown zone' };

  await readings.save(r);
  latest[zone.id] = r;
  bus.emit('telemetry', r);

  for (const a of evaluateReading(zone, r)) await raise(zone.id, a);

  const action = decideIrrigation(zone, r);
  if (action) await setRelay(zone.id, { on: action === 'start' }, { source: 'auto' });
  return { ok: true, reading: r };
}
