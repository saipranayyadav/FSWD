// Pure business rules (no I/O) so they are trivial to unit-test.

/** Which alerts does this reading trigger for this zone? */
export function evaluateReading(zone, r) {
  const out = [];
  if (r.soil < zone.dry * 0.8) {
    out.push({ key: `${zone.id}-dry`, level: 'critical', message: `${zone.name} (${zone.crop}) soil moisture is critically low at ${r.soil}%` });
  } else if (r.soil < zone.dry) {
    out.push({ key: `${zone.id}-dry`, level: 'warning', message: `${zone.name} (${zone.crop}) soil is drying out at ${r.soil}%` });
  }
  if (r.temp > 34) out.push({ key: `${zone.id}-heat`, level: 'warning', message: `${zone.name} air temperature is high at ${r.temp}°C` });
  if (r.humidity > 90) out.push({ key: `${zone.id}-humid`, level: 'info', message: `${zone.name} humidity is very high at ${r.humidity}% - check ventilation` });
  return out;
}

/** Hysteresis controller for automatic irrigation. Returns 'start', 'stop' or null. */
export function decideIrrigation(zone, r) {
  if (!zone.relay.auto) return null;
  if (!zone.relay.on && r.soil < zone.dry - 4) return 'start';
  if (zone.relay.on && r.soil > zone.wet) return 'stop';
  return null;
}

/** Status label used in summaries. */
export function soilStatus(soil, dry) {
  if (soil < dry * 0.8) return 'critical';
  if (soil < dry) return 'dry';
  if (soil > 70) return 'saturated';
  return 'healthy';
}
