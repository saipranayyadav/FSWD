import { EventEmitter } from 'events';

/** Internal event bus: 'telemetry', 'relay', 'alert', 'command'.
 *  Socket.IO, SSE and MQTT all subscribe here, so producers never know who is listening. */
export const bus = new EventEmitter();
bus.setMaxListeners(50);
