// AI-augmented insights (CO6). Always produces rule-based advice; if ANTHROPIC_API_KEY is
// configured it also asks Claude to turn the same numbers into a short plain-language briefing.
import { config } from '../config.js';
import { soilStatus } from './rules.js';

export function ruleBasedInsights(stats, zones) {
  const byId = Object.fromEntries(zones.map((z) => [z.id, z]));
  const recs = [];
  for (const s of stats) {
    const z = byId[s.zone];
    if (!z || s.samples === 0) continue;
    const status = soilStatus(s.soil.avg, z.dry);
    if (status === 'critical' || status === 'dry') {
      recs.push({ zone: s.zone, level: status === 'critical' ? 'critical' : 'warning',
        text: `${z.crop} in ${z.name} averaged ${s.soil.avg}% soil moisture (limit ${z.dry}%). Increase irrigation or enable automatic mode.` });
    } else if (status === 'saturated') {
      recs.push({ zone: s.zone, level: 'info', text: `${z.crop} in ${z.name} is very wet (${s.soil.avg}%). Reduce irrigation to avoid root disease.` });
    }
    if (s.temp.max > 34) recs.push({ zone: s.zone, level: 'warning', text: `${z.name} peaked at ${s.temp.max}°C. Open vents or add shading around midday.` });
    if (s.soil.max - s.soil.min > 35) recs.push({ zone: s.zone, level: 'info', text: `${z.name} soil moisture swings by ${Math.round(s.soil.max - s.soil.min)} points. Shorter, more frequent irrigation cycles would be steadier.` });
  }
  if (!recs.length) recs.push({ zone: null, level: 'info', text: 'All zones are within their target ranges. No action needed.' });
  return recs;
}

async function askClaude(stats, zones, recs) {
  const prompt = `You are an agronomy assistant for a greenhouse. Using ONLY this JSON, write a briefing of at most 90 words for the operator.
Be concrete, mention zones by name, and do not invent numbers.
${JSON.stringify({ zones, last24h: stats, ruleFindings: recs.map((r) => r.text) })}`;
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), 15_000);
  try {
    const res = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      signal: ctrl.signal,
      headers: { 'content-type': 'application/json', 'x-api-key': config.anthropicKey, 'anthropic-version': '2023-06-01' },
      body: JSON.stringify({ model: config.anthropicModel, max_tokens: 300, messages: [{ role: 'user', content: prompt }] }),
    });
    if (!res.ok) throw new Error(`Anthropic API ${res.status}`);
    const data = await res.json();
    return data.content.filter((b) => b.type === 'text').map((b) => b.text).join('\n').trim();
  } finally {
    clearTimeout(timer);
  }
}

export async function buildInsights(stats, zones) {
  const recommendations = ruleBasedInsights(stats, zones);
  let summary = null;
  let source = 'rules';
  if (config.anthropicKey) {
    try { summary = await askClaude(stats, zones, recommendations); source = 'claude'; }
    catch (e) { console.error('[insights] AI call failed, using rules only:', e.message); }
  }
  return { source, generatedAt: Date.now(), summary, recommendations };
}
