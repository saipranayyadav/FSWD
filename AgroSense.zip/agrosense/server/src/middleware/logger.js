export function logger(req, res, next) {
  const start = Date.now();
  // never write JWTs (sent as ?token= by the SSE client) into the logs
  const url = req.originalUrl.replace(/([?&]token=)[^&]+/, '$1***');
  res.on('finish', () => console.log(`${req.method} ${url} ${res.statusCode} ${Date.now() - start}ms`));
  next();
}
