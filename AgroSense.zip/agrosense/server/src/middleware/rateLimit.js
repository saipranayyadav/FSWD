/** Tiny sliding-window limiter: `max` requests per `windowMs` per client IP. */
export function rateLimit({ windowMs = 60_000, max = 300 } = {}) {
  const hits = new Map();
  setInterval(() => {
    const now = Date.now();
    for (const [ip, list] of hits) { const keep = list.filter((t) => now - t < windowMs); keep.length ? hits.set(ip, keep) : hits.delete(ip); }
  }, windowMs).unref();

  return (req, res, next) => {
    const now = Date.now();
    const list = (hits.get(req.ip) || []).filter((t) => now - t < windowMs);
    list.push(now);
    hits.set(req.ip, list);
    res.set('X-RateLimit-Limit', String(max));
    res.set('X-RateLimit-Remaining', String(Math.max(0, max - list.length)));
    if (list.length > max) return res.status(429).json({ error: 'Too many requests' });
    next();
  };
}
