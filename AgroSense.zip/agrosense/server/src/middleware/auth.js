import jwt from 'jsonwebtoken';
import { config } from '../config.js';
import { HttpError } from './errors.js';

export const signToken = (user) => jwt.sign({ sub: user.id, role: user.role, name: user.name }, config.jwtSecret, { expiresIn: '8h' });
export const verifyToken = (token) => jwt.verify(token, config.jwtSecret);

const bearer = (req) => (req.headers.authorization || '').replace(/^Bearer\s+/i, '') || null;

function attachUser(req, token) {
  const p = verifyToken(token);
  req.user = { id: p.sub, role: p.role, name: p.name };
}

/** Requires a valid JWT. SSE can't set headers, so ?token= is also accepted. */
export function requireAuth(req, res, next) {
  const token = bearer(req) || req.query.token;
  if (!token) return next(new HttpError(401, 'Authentication required'));
  try { attachUser(req, token); next(); } catch { next(new HttpError(401, 'Invalid or expired token')); }
}

export const requireRole = (...roles) => (req, res, next) =>
  roles.includes(req.user?.role) ? next() : next(new HttpError(403, 'You do not have permission to do this'));

/** Either a logged-in admin (JWT) or a device holding the shared API key. */
export function adminOrDevice(req, res, next) {
  if (req.headers['x-api-key'] === config.deviceKey) { req.user = { id: null, role: 'device', name: 'device' }; return next(); }
  requireAuth(req, res, (err) => (err ? next(err) : requireRole('admin')(req, res, next)));
}
