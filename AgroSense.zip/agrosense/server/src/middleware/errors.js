export class HttpError extends Error {
  constructor(status, message, details) {
    super(message);
    this.status = status;
    this.details = details;
  }
}

/** Express 4 does not catch rejected promises - wrap async handlers with this. */
export const asyncHandler = (fn) => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);

export const notFound = (req, res) => res.status(404).json({ error: 'Not found' });

// eslint-disable-next-line no-unused-vars
export function errorHandler(err, req, res, next) {
  if (err instanceof HttpError) return res.status(err.status).json({ error: err.message, details: err.details });
  if (err?.type === 'entity.parse.failed') return res.status(400).json({ error: 'Invalid JSON body' });
  if (err?.code === '23505') return res.status(409).json({ error: 'Already exists' }); // PostgreSQL unique_violation
  if (err?.code === '23503') return res.status(400).json({ error: 'Referenced record does not exist' }); // foreign_key_violation
  console.error(err);
  res.status(500).json({ error: 'Internal server error' });
}
