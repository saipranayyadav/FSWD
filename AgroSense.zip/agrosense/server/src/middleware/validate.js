import { HttpError } from './errors.js';

/**
 * Minimal schema validator.
 *   field: { type: 'string'|'number'|'boolean', required, min, max, minLength, maxLength, pattern, enum, transform }
 * Returns { value, errors } - unknown fields are dropped, numbers sent as strings are coerced.
 */
export function check(schema, input = {}) {
  const value = {};
  const errors = {};
  for (const [name, rule] of Object.entries(schema)) {
    let v = input[name];
    if (v === undefined || v === null || v === '') {
      if (rule.required) errors[name] = 'is required';
      continue;
    }
    if (rule.type === 'number') {
      if (typeof v === 'string' && v.trim() !== '') v = Number(v);
      if (typeof v !== 'number' || !Number.isFinite(v)) { errors[name] = 'must be a number'; continue; }
      if (rule.min !== undefined && v < rule.min) { errors[name] = `must be >= ${rule.min}`; continue; }
      if (rule.max !== undefined && v > rule.max) { errors[name] = `must be <= ${rule.max}`; continue; }
    } else if (rule.type === 'boolean') {
      if (typeof v !== 'boolean') { errors[name] = 'must be true or false'; continue; }
    } else {
      if (typeof v !== 'string') { errors[name] = 'must be text'; continue; }
      v = v.trim();
      if (rule.minLength && v.length < rule.minLength) { errors[name] = `must be at least ${rule.minLength} characters`; continue; }
      if (rule.maxLength && v.length > rule.maxLength) { errors[name] = `must be at most ${rule.maxLength} characters`; continue; }
      if (rule.pattern && !rule.pattern.test(v)) { errors[name] = 'has an invalid format'; continue; }
      if (rule.enum && !rule.enum.includes(v)) { errors[name] = `must be one of: ${rule.enum.join(', ')}`; continue; }
    }
    value[name] = rule.transform ? rule.transform(v) : v;
  }
  return { value, errors };
}

/** Middleware: validates req[source] and replaces it with the cleaned value. */
export const validate = (schema, source = 'body') => (req, res, next) => {
  const { value, errors } = check(schema, req[source]);
  if (Object.keys(errors).length) return next(new HttpError(400, 'Validation failed', errors));
  req[source] = value;
  next();
};
