-- AgroSense relational + time-series schema (PostgreSQL, TimescaleDB optional)

CREATE TABLE IF NOT EXISTS users (
  id            SERIAL PRIMARY KEY,
  username      TEXT,
  email         TEXT NOT NULL UNIQUE,
  name          TEXT NOT NULL,
  password_hash TEXT NOT NULL,
  role          TEXT NOT NULL DEFAULT 'viewer' CHECK (role IN ('admin', 'viewer')),
  created_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Upgrade path for databases created before usernames existed
ALTER TABLE users ADD COLUMN IF NOT EXISTS username TEXT;
UPDATE users SET username = split_part(email, '@', 1) WHERE username IS NULL;
ALTER TABLE users ALTER COLUMN username SET NOT NULL;
CREATE UNIQUE INDEX IF NOT EXISTS users_username_key ON users (lower(username));

CREATE TABLE IF NOT EXISTS zones (
  id            TEXT PRIMARY KEY,
  name          TEXT NOT NULL,
  crop          TEXT NOT NULL,
  dry_threshold REAL NOT NULL DEFAULT 30 CHECK (dry_threshold BETWEEN 0 AND 100),
  wet_threshold REAL NOT NULL DEFAULT 62 CHECK (wet_threshold BETWEEN 0 AND 100),
  relay_on      BOOLEAN NOT NULL DEFAULT FALSE,
  auto_mode     BOOLEAN NOT NULL DEFAULT TRUE,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Time-series table. Becomes a TimescaleDB hypertable when the extension exists.
CREATE TABLE IF NOT EXISTS readings (
  time          TIMESTAMPTZ NOT NULL,
  zone_id       TEXT NOT NULL REFERENCES zones(id) ON DELETE CASCADE,
  soil_moisture REAL NOT NULL,
  temperature   REAL NOT NULL,
  humidity      REAL NOT NULL,
  light         REAL NOT NULL
);
CREATE INDEX IF NOT EXISTS readings_zone_time ON readings (zone_id, time DESC);

CREATE TABLE IF NOT EXISTS alerts (
  id              SERIAL PRIMARY KEY,
  time            TIMESTAMPTZ NOT NULL DEFAULT now(),
  zone_id         TEXT REFERENCES zones(id) ON DELETE CASCADE,
  level           TEXT NOT NULL CHECK (level IN ('info', 'warning', 'critical')),
  message         TEXT NOT NULL,
  acknowledged    BOOLEAN NOT NULL DEFAULT FALSE,
  acknowledged_by INTEGER REFERENCES users(id) ON DELETE SET NULL
);
CREATE INDEX IF NOT EXISTS alerts_time ON alerts (time DESC);

CREATE TABLE IF NOT EXISTS irrigation_events (
  id      SERIAL PRIMARY KEY,
  time    TIMESTAMPTZ NOT NULL DEFAULT now(),
  zone_id TEXT NOT NULL REFERENCES zones(id) ON DELETE CASCADE,
  action  TEXT NOT NULL CHECK (action IN ('start', 'stop')),
  source  TEXT NOT NULL CHECK (source IN ('manual', 'auto')),
  user_id INTEGER REFERENCES users(id) ON DELETE SET NULL
);
CREATE INDEX IF NOT EXISTS irrigation_time ON irrigation_events (time DESC);

-- Latest reading per zone (DISTINCT ON is a PostgreSQL feature)
CREATE OR REPLACE VIEW v_zone_latest AS
SELECT DISTINCT ON (zone_id) zone_id, time, soil_moisture, temperature, humidity, light
  FROM readings
 ORDER BY zone_id, time DESC;

-- Uses TimescaleDB hypertables when the extension exists, plain PostgreSQL otherwise.
DO $$ BEGIN
  CREATE EXTENSION IF NOT EXISTS timescaledb;
  PERFORM create_hypertable('readings', 'time', if_not_exists => TRUE, migrate_data => TRUE);
EXCEPTION WHEN OTHERS THEN
  RAISE NOTICE 'TimescaleDB not available, using plain PostgreSQL';
END $$;
