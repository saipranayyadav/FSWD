import test from 'node:test';
import assert from 'node:assert/strict';
import { ruleBasedInsights } from '../src/services/insights.js';

const zones = [{ id: 'A', name: 'Zone A', crop: 'Tomato', dry: 32 }];
const base = { zone: 'A', samples: 100, soil: { avg: 50, min: 40, max: 60 }, temp: { avg: 25, min: 20, max: 30 }, humidity: 60, light: 1 };

test('no findings -> all-clear message', () => {
  const r = ruleBasedInsights([base], zones);
  assert.equal(r.length, 1);
  assert.match(r[0].text, /No action needed/);
});

test('dry and hot zone produce actionable advice', () => {
  const r = ruleBasedInsights([{ ...base, soil: { avg: 20, min: 15, max: 25 }, temp: { avg: 30, min: 22, max: 37 } }], zones);
  assert.equal(r[0].level, 'critical');
  assert.ok(r.some((x) => /vents|shading/.test(x.text)));
});
