import test from 'node:test';
import assert from 'node:assert/strict';
import { check } from '../src/middleware/validate.js';

const schema = {
  soil: { type: 'number', required: true, min: 0, max: 100 },
  name: { type: 'string', required: true, minLength: 2 },
  mode: { type: 'string', enum: ['a', 'b'] },
  flag: { type: 'boolean' },
};

test('accepts valid input and coerces numeric strings', () => {
  const { value, errors } = check(schema, { soil: '42.5', name: '  Tomato ', extra: 'dropped' });
  assert.deepEqual(errors, {});
  assert.deepEqual(value, { soil: 42.5, name: 'Tomato' });
});

test('reports missing, out-of-range and wrong-type fields', () => {
  const { errors } = check(schema, { soil: 150, mode: 'z', flag: 'yes' });
  assert.equal(errors.soil, 'must be <= 100');
  assert.equal(errors.name, 'is required');
  assert.match(errors.mode, /must be one of/);
  assert.equal(errors.flag, 'must be true or false');
});

test('rejects NaN and non-numeric text', () => {
  assert.equal(check(schema, { soil: 'abc', name: 'ok' }).errors.soil, 'must be a number');
});
