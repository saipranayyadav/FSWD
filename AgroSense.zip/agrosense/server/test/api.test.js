// Integration test: boots the real Express app against an in-memory PostgreSQL (PGlite).
// Run with:  npm test   (needs `npm install` first)
import test, { before, after } from 'node:test';
import assert from 'node:assert/strict';
import http from 'http';

process.env.DB_MEMORY = 'true';
process.env.JWT_SECRET = 'test-secret';
process.env.DEVICE_API_KEY = 'test-device';

const { initDb, closeDb } = await import('../src/db/index.js');
const { seed } = await import('../src/services/seed.js');
const { createApp } = await import('../src/app.js');

let server, base, token;
const call = async (path, { method = 'GET', body, headers = {} } = {}) => {
  const res = await fetch(base + path, {
    method,
    headers: { 'content-type': 'application/json', ...(token ? { authorization: `Bearer ${token}` } : {}), ...headers },
    body: body ? JSON.stringify(body) : undefined,
  });
  const text = await res.text();
  return { status: res.status, json: text ? JSON.parse(text) : null };
};

before(async () => {
  await initDb();
  await seed();
  server = http.createServer(createApp());
  await new Promise((r) => server.listen(0, r));
  base = `http://127.0.0.1:${server.address().port}`;
});
after(async () => { server.closeAllConnections?.(); server.close(); await closeDb(); });

test('health is public', async () => {
  const r = await call('/api/health');
  assert.equal(r.status, 200);
  assert.equal(r.json.status, 'ok');
});

test('protected routes reject anonymous users', async () => {
  assert.equal((await call('/api/zones')).status, 401);
});

test('login fails with a wrong password and succeeds with the seeded admin', async () => {
  assert.equal((await call('/api/auth/login', { method: 'POST', body: { username: 'admin', password: 'nope-nope' } })).status, 401);
  const ok = await call('/api/auth/login', { method: 'POST', body: { username: 'admin', password: 'admin123' } });
  assert.equal(ok.status, 200);
  token = ok.json.token;
});

test('zones: list seeded zones, validate and create a new one', async () => {
  const list = await call('/api/zones');
  assert.equal(list.json.length, 3);
  const bad = await call('/api/zones', { method: 'POST', body: { id: 'D', name: 'x' } });
  assert.equal(bad.status, 400);
  const created = await call('/api/zones', { method: 'POST', body: { id: 'd', name: 'Zone D', crop: 'Basil', dry: 28 } });
  assert.equal(created.status, 201);
  assert.equal(created.json.id, 'D');
  assert.equal((await call('/api/zones', { method: 'POST', body: { id: 'D', name: 'Zone D', crop: 'Basil' } })).status, 409);
});

test('readings: manual input is stored, raises an alert, and appears in history', async () => {
  const r = await call('/api/readings', { method: 'POST', body: { zone: 'A', soil: 10, temp: 26, humidity: 60, light: 15000 } });
  assert.equal(r.status, 201);
  const alerts = await call('/api/alerts');
  assert.ok(alerts.json.items.some((a) => a.zone === 'A' && a.level === 'critical'));
  const hist = await call('/api/history?zone=A&hours=1&bucket=1');
  assert.ok(hist.json.length >= 1);
});

test('readings: device API key works without a JWT; bad key is rejected', async () => {
  const saved = token; token = null;
  const body = { zone: 'B', soil: 50, temp: 24, humidity: 70, light: 10000 };
  assert.equal((await call('/api/readings', { method: 'POST', body, headers: { 'x-api-key': 'test-device' } })).status, 201);
  assert.equal((await call('/api/readings', { method: 'POST', body, headers: { 'x-api-key': 'wrong' } })).status, 401);
  token = saved;
});

test('irrigation: manual start is logged and switches auto mode off', async () => {
  const r = await call('/api/irrigation/B', { method: 'POST', body: { on: true } });
  assert.deepEqual(r.json, { on: true, auto: false });
  const events = await call('/api/irrigation/events');
  assert.equal(events.json[0].action, 'start');
});

test('registration rejects bad input and duplicate usernames, then the new user can log in', async () => {
  const saved = token; token = null;
  assert.equal((await call('/api/auth/register', { method: 'POST', body: { username: 'ab', email: 'bad', password: '123' } })).status, 400);
  const ok = await call('/api/auth/register', { method: 'POST', body: { username: 'Farmer_Raju', email: 'raju@example.com', password: 'secret1' } });
  assert.equal(ok.status, 201);
  assert.equal(ok.json.user.username, 'Farmer_Raju');
  const dup = await call('/api/auth/register', { method: 'POST', body: { username: 'farmer_raju', email: 'other@example.com', password: 'secret1' } });
  assert.equal(dup.status, 409);
  assert.equal(dup.json.details.username, 'is already taken');
  assert.equal((await call('/api/auth/login', { method: 'POST', body: { username: 'farmer_raju', password: 'secret1' } })).status, 200);
  token = saved;
});

test('a viewer cannot control irrigation', async () => {
  const reg = await call('/api/auth/register', { method: 'POST', body: { username: 'vera_viewer', email: 'v@example.com', password: 'secret1' } });
  assert.equal(reg.status, 201);
  const saved = token; token = reg.json.token;
  assert.equal((await call('/api/irrigation/A', { method: 'POST', body: { on: true } })).status, 403);
  token = saved;
});

test('insights and stats endpoints respond', async () => {
  assert.equal((await call('/api/insights')).json.source, 'rules');
  assert.ok(Array.isArray((await call('/api/stats?hours=24')).json));
});
