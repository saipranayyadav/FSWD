import test from 'node:test';
import assert from 'node:assert/strict';
import { evaluateReading, decideIrrigation, soilStatus } from '../src/services/rules.js';

const zone = { id: 'A', name: 'Zone A', crop: 'Tomato', dry: 32, wet: 62, relay: { on: false, auto: true } };

test('critical alert when soil is below 80% of the dry limit', () => {
  const a = evaluateReading(zone, { soil: 20, temp: 25, humidity: 60, light: 1000 });
  assert.equal(a[0].level, 'critical');
});

test('warning when slightly dry, none when healthy', () => {
  assert.equal(evaluateReading(zone, { soil: 30, temp: 25, humidity: 60, light: 0 })[0].level, 'warning');
  assert.equal(evaluateReading(zone, { soil: 50, temp: 25, humidity: 60, light: 0 }).length, 0);
});

test('heat and humidity alerts', () => {
  const keys = evaluateReading(zone, { soil: 50, temp: 36, humidity: 95, light: 0 }).map((a) => a.key);
  assert.deepEqual(keys, ['A-heat', 'A-humid']);
});

test('irrigation controller uses hysteresis', () => {
  assert.equal(decideIrrigation(zone, { soil: 27 }), 'start');
  assert.equal(decideIrrigation(zone, { soil: 31 }), null);
  const running = { ...zone, relay: { on: true, auto: true } };
  assert.equal(decideIrrigation(running, { soil: 50 }), null);
  assert.equal(decideIrrigation(running, { soil: 63 }), 'stop');
  assert.equal(decideIrrigation({ ...zone, relay: { on: false, auto: false } }, { soil: 5 }), null);
});

test('soilStatus labels', () => {
  assert.equal(soilStatus(10, 32), 'critical');
  assert.equal(soilStatus(75, 32), 'saturated');
});
