// ESP32 sensor node: soil moisture + DHT22 + LDR, relay-controlled irrigation over MQTT.
#include <WiFi.h>
#include <PubSubClient.h>
#include <DHT.h>

#define ZONE "A"
const char* WIFI_SSID = "your-wifi";
const char* WIFI_PASS = "your-password";
const char* MQTT_HOST = "192.168.1.10";

#define SOIL_PIN 34
#define LDR_PIN 35
#define DHT_PIN 4
#define RELAY_PIN 26
const int SOIL_DRY = 3200, SOIL_WET = 1300;   // calibrate for your probe

DHT dht(DHT_PIN, DHT22);
WiFiClient net;
PubSubClient mqtt(net);
String teleTopic = String("agrosense/") + ZONE + "/telemetry";
String cmdTopic = String("agrosense/") + ZONE + "/irrigation";

void onMessage(char* topic, byte* payload, unsigned int len) {
  String body((char*)payload, len);
  digitalWrite(RELAY_PIN, body.indexOf("true") >= 0 ? HIGH : LOW);
}

void connectAll() {
  if (WiFi.status() != WL_CONNECTED) { WiFi.begin(WIFI_SSID, WIFI_PASS); while (WiFi.status() != WL_CONNECTED) delay(300); }
  while (!mqtt.connected()) { if (mqtt.connect("agrosense-" ZONE)) mqtt.subscribe(cmdTopic.c_str()); else delay(1500); }
}

void setup() {
  pinMode(RELAY_PIN, OUTPUT);
  dht.begin();
  mqtt.setServer(MQTT_HOST, 1883);
  mqtt.setCallback(onMessage);
}

void loop() {
  connectAll();
  mqtt.loop();
  static unsigned long last = 0;
  if (millis() - last < 2000) return;
  last = millis();
  float soil = constrain(map(analogRead(SOIL_PIN), SOIL_DRY, SOIL_WET, 0, 100), 0, 100);
  float light = analogRead(LDR_PIN) * 52000.0 / 4095.0;
  char buf[128];
  snprintf(buf, sizeof(buf), "{\"soil\":%.1f,\"temp\":%.1f,\"humidity\":%.1f,\"light\":%.0f}", soil, dht.readTemperature(), dht.readHumidity(), light);
  mqtt.publish(teleTopic.c_str(), buf);
}
