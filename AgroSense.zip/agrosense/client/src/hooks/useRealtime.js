import { useEffect } from 'react';
import { io } from 'socket.io-client';
import { api, tokenStore } from '../lib/api';

/**
 * Real-time transport (CO5):
 *  - WebSocket (Socket.IO): sensor telemetry + relay state, two-way capable
 *  - Server-Sent Events:    alert feed, one-way and auto-reconnecting
 */
export function useRealtime(user, dispatch) {
  useEffect(() => {
    if (!user) return undefined;
    const token = tokenStore.get();

    const socket = io(api.base || undefined, { auth: { token }, transports: ['websocket', 'polling'] });
    socket.on('connect', () => dispatch({ type: 'connection', connection: 'live' }));
    socket.on('disconnect', () => dispatch({ type: 'connection', connection: 'offline' }));
    socket.on('connect_error', () => dispatch({ type: 'connection', connection: 'offline' }));
    socket.on('telemetry', (reading) => dispatch({ type: 'telemetry', reading }));
    socket.on('relay', (relay) => dispatch({ type: 'relay', relay }));

    const events = new EventSource(`${api.base}/api/alerts/stream?token=${encodeURIComponent(token ?? '')}`);
    events.addEventListener('alert', (e) => dispatch({ type: 'alert-new', alert: JSON.parse(e.data) }));

    return () => { socket.disconnect(); events.close(); };
  }, [user, dispatch]);
}
