import { createContext, useCallback, useContext, useEffect, useMemo, useReducer } from 'react';
import { api, tokenStore } from '../lib/api';
import { initialState, reducer } from '../lib/reducer';
import { useRealtime } from '../hooks/useRealtime';

const AppContext = createContext(null);

/** Global state (useReducer + Context) plus the actions that talk to the API. */
export function AppProvider({ children }) {
  const [state, dispatch] = useReducer(reducer, initialState);

  // 1. On first load: is there a saved token that is still valid?
  useEffect(() => {
    if (!tokenStore.get()) { dispatch({ type: 'booted', user: null }); return; }
    api.me()
      .then(({ user }) => dispatch({ type: 'booted', user }))
      .catch(() => { tokenStore.clear(); dispatch({ type: 'booted', user: null }); });
  }, []);

  const loadZones = useCallback(() => api.zones().then((zones) => dispatch({ type: 'zones', zones })), []);
  const loadAlerts = useCallback(async () => {
    const page = await api.alerts(50);
    dispatch({ type: 'alerts', alerts: page.items, unacked: page.items.filter((a) => !a.acknowledged).length });
  }, []);

  // 2. Once logged in: load data, then keep it live over WebSocket + SSE.
  useEffect(() => {
    if (!state.user) return;
    loadZones().catch((e) => dispatch({ type: 'toast', message: e.message }));
    loadAlerts().catch(() => {});
  }, [state.user, loadZones, loadAlerts]);
  useRealtime(state.user, dispatch);

  const actions = useMemo(() => ({
    async login(username, password) {
      const { token, user } = await api.login(username, password);
      tokenStore.set(token);
      dispatch({ type: 'login', user });
    },
    async register(username, email, password) {
      const { token, user } = await api.register(username, email, password);
      tokenStore.set(token);
      dispatch({ type: 'login', user });
    },
    logout() { tokenStore.clear(); dispatch({ type: 'logout' }); },
    toast: (message) => dispatch({ type: 'toast', message }),
    loadZones, loadAlerts,
  }), [loadZones, loadAlerts]);

  return <AppContext.Provider value={{ state, dispatch, actions }}>{children}</AppContext.Provider>;
}

export const useApp = () => useContext(AppContext);
