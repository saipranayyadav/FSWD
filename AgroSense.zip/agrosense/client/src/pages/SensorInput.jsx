import { useState } from 'react';
import { useApp } from '../context/AppContext';
import { api } from '../lib/api';
import Field from '../components/Field';

export default function SensorInput() {
  const { state, actions } = useApp();
  const isAdmin = state.user?.role === 'admin';
  const [form, setForm] = useState({ zone: state.zones[0]?.id ?? 'A', soil: '58', temp: '26', humidity: '65', light: '18000' });
  const [errors, setErrors] = useState({});
  const set = (k) => (e) => setForm((f) => ({ ...f, [k]: e.target.value }));

  async function submit(e) {
    e.preventDefault();
    setErrors({});
    try {
      await api.addReading({ zone: form.zone, soil: Number(form.soil), temp: Number(form.temp), humidity: Number(form.humidity), light: Number(form.light) });
      actions.toast(`Reading saved to the database for zone ${form.zone}`);
    } catch (err) { setErrors({ ...(err.details || {}), _: err.message }); }
  }

  return (
    <section className="card" aria-labelledby="input-title">
      <h2 id="input-title">Manual sensor input</h2>
      <p className="muted">Readings are validated by the API, stored in PostgreSQL, then pushed to every open dashboard. Try a soil value below the zone's dry limit to raise an alert.</p>
      {!isAdmin && <p className="form-error" role="alert">Only admins can submit readings.</p>}
      <form onSubmit={submit} className="form-grid" noValidate>
        <div className="field">
          <label htmlFor="zone">Growing zone</label>
          <select id="zone" value={form.zone} onChange={set('zone')}>
            {state.zones.map((z) => <option key={z.id} value={z.id}>Zone {z.id} — {z.crop}</option>)}
          </select>
        </div>
        <Field label="Soil moisture (%)" type="number" value={form.soil} onChange={set('soil')} error={errors.soil} required />
        <Field label="Temperature (°C)" type="number" value={form.temp} onChange={set('temp')} error={errors.temp} required />
        <Field label="Humidity (%)" type="number" value={form.humidity} onChange={set('humidity')} error={errors.humidity} required />
        <Field label="Light intensity (lux)" type="number" value={form.light} onChange={set('light')} error={errors.light} required />
        {errors._ && <p className="form-error" role="alert">{errors._}</p>}
        <button className="btn primary" disabled={!isAdmin}>Save reading</button>
      </form>
    </section>
  );
}
