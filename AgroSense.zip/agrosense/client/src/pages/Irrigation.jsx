import { useState } from 'react';
import { useApp } from '../context/AppContext';
import { useAsync } from '../hooks/useAsync';
import { api } from '../lib/api';
import { cropIcon, dateTime, fmt } from '../lib/format';

export default function Irrigation() {
  const { state, actions } = useApp();
  const isAdmin = state.user?.role === 'admin';
  const [busy, setBusy] = useState('');
  const events = useAsync(() => api.irrigationEvents(15), []);

  async function change(zone, body) {
    setBusy(zone.id);
    try { await api.setIrrigation(zone.id, body); events.reload(); }   // state arrives via WebSocket 'relay'
    catch (err) { actions.toast(err.message); }
    finally { setBusy(''); }
  }

  return (
    <>
      <div className="grid zones">
        {state.zones.map((z) => {
          const relay = state.relay[z.id] ?? { on: false, auto: true };
          const soil = state.latest[z.id]?.soil;
          return (
            <section className="card" key={z.id} aria-labelledby={`irr-${z.id}`}>
              <h2 id={`irr-${z.id}`}>{cropIcon(z.crop)} {z.crop} · Zone {z.id}</h2>
              <p className="muted">Soil {fmt(soil)}% · dry limit {z.dry}% · stop at {z.wet}%</p>
              <p>Status: <span className={`badge ${relay.on ? 'good' : 'off'}`}>{relay.on ? 'Running' : 'Standby'}</span></p>
              <label className="switch-row">
                <input type="checkbox" checked={relay.auto} disabled={!isAdmin || busy === z.id} onChange={(e) => change(z, { auto: e.target.checked })} />
                Automatic irrigation
              </label>
              <button type="button" className={`btn ${relay.on ? 'danger' : 'primary'}`} disabled={!isAdmin || busy === z.id} onClick={() => change(z, { on: !relay.on })}>
                {relay.on ? 'Stop irrigation' : 'Start irrigation'}
              </button>
            </section>
          );
        })}
      </div>
      {!isAdmin && <p className="muted">Viewer accounts can watch irrigation but not control it.</p>}

      <section className="card" aria-labelledby="log-title">
        <div className="row"><h2 id="log-title">Irrigation log</h2><button className="btn ghost" type="button" onClick={events.reload}>Refresh</button></div>
        <div className="table-wrap">
          <table>
            <caption className="sr-only">Most recent irrigation start and stop events</caption>
            <thead><tr><th scope="col">Time</th><th scope="col">Zone</th><th scope="col">Action</th><th scope="col">Source</th><th scope="col">By</th></tr></thead>
            <tbody>
              {(events.data ?? []).map((e) => (
                <tr key={e.id}><td><time dateTime={new Date(e.time).toISOString()}>{dateTime(e.time)}</time></td><td>{e.zone}</td><td>{e.action}</td><td>{e.source}</td><td>{e.user ?? (e.source === 'auto' ? 'controller' : '–')}</td></tr>
              ))}
              {events.data?.length === 0 && <tr><td colSpan="5" className="empty">No irrigation events yet.</td></tr>}
            </tbody>
          </table>
        </div>
      </section>
    </>
  );
}
