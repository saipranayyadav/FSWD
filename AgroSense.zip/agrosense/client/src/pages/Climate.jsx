import { useMemo, useState } from 'react';
import { CartesianGrid, Legend, Line, LineChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';
import { useApp } from '../context/AppContext';
import { useAsync } from '../hooks/useAsync';
import { api } from '../lib/api';
import { METRICS, clock, dateTime, fmt, pivotHistory, zoneColor } from '../lib/format';

const RANGES = { '1h': [1, 1], '6h': [6, 5], '24h': [24, 15], '7d': [168, 60] }; // [hours, bucket minutes]

export default function Climate() {
  const { state } = useApp();
  const [range, setRange] = useState('6h');
  const [metric, setMetric] = useState('soil');
  const [hours, bucket] = RANGES[range];
  const ids = state.zones.map((z) => z.id);

  const history = useAsync(() => api.history('all', hours, bucket), [hours, bucket]);
  const stats = useAsync(() => api.stats(hours), [hours]);
  const data = useMemo(() => pivotHistory(history.data ?? [], metric), [history.data, metric]);
  const tick = hours > 24 ? dateTime : clock;

  return (
    <>
      <section className="card" aria-labelledby="trend-title">
        <div className="row wrap">
          <h2 id="trend-title">{METRICS[metric].label} history</h2>
          <div className="controls">
            <div className="seg" role="group" aria-label="Time range">
              {Object.keys(RANGES).map((r) => <button key={r} type="button" aria-pressed={r === range} className={r === range ? 'sel' : ''} onClick={() => setRange(r)}>{r}</button>)}
            </div>
            <label className="inline">Metric
              <select value={metric} onChange={(e) => setMetric(e.target.value)}>
                {Object.entries(METRICS).map(([k, m]) => <option key={k} value={k}>{m.label}</option>)}
              </select>
            </label>
          </div>
        </div>
        {history.loading && <p className="empty" role="status">Loading time-series from the database…</p>}
        {history.error && <p className="form-error" role="alert">{history.error.message}</p>}
        {!history.loading && !history.error && (
          <div className="chart-box" role="img" aria-label={`${METRICS[metric].label} over the last ${range}`}>
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={data} margin={{ left: -10, right: 8, top: 8 }}>
                <CartesianGrid stroke="var(--line)" vertical={false} />
                <XAxis dataKey="t" tickFormatter={tick} minTickGap={50} tick={{ fontSize: 11 }} />
                <YAxis domain={['auto', 'auto']} tick={{ fontSize: 11 }} unit={METRICS[metric].unit.trim()} />
                <Tooltip labelFormatter={tick} />
                <Legend />
                {state.zones.map((z) => <Line key={z.id} name={`${z.crop} (${z.id})`} dataKey={z.id} stroke={zoneColor(ids, z.id)} strokeWidth={2} dot={false} isAnimationActive={false} connectNulls />)}
              </LineChart>
            </ResponsiveContainer>
          </div>
        )}
      </section>

      <section className="card" aria-labelledby="stats-title">
        <h2 id="stats-title">Zone statistics (last {range})</h2>
        <div className="table-wrap">
          <table>
            <caption className="sr-only">Minimum, average and maximum per growing zone, computed by SQL aggregates</caption>
            <thead>
              <tr><th scope="col">Zone</th><th scope="col">Samples</th><th scope="col">Soil min / avg / max %</th><th scope="col">Temp min / avg / max °C</th><th scope="col">Humidity %</th><th scope="col">Light lux</th></tr>
            </thead>
            <tbody>
              {(stats.data ?? []).map((s) => (
                <tr key={s.zone}>
                  <th scope="row">{s.zone} · {s.crop}</th>
                  <td>{s.samples}</td>
                  <td>{fmt(s.soil.min)} / {fmt(s.soil.avg)} / {fmt(s.soil.max)}</td>
                  <td>{fmt(s.temp.min)} / {fmt(s.temp.avg)} / {fmt(s.temp.max)}</td>
                  <td>{fmt(s.humidity)}</td>
                  <td>{s.light.toLocaleString()}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>
    </>
  );
}
