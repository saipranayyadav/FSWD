import { useState } from 'react';
import { useApp } from '../context/AppContext';
import { api } from '../lib/api';
import ZoneCard from '../components/ZoneCard';
import Field from '../components/Field';

const blank = { id: '', name: '', crop: '', dry: '30', wet: '62' };

export default function Zones() {
  const { state, actions } = useApp();
  const isAdmin = state.user?.role === 'admin';
  const [form, setForm] = useState(blank);
  const [errors, setErrors] = useState({});
  const set = (k) => (e) => setForm((f) => ({ ...f, [k]: e.target.value }));

  async function add(e) {
    e.preventDefault();
    setErrors({});
    try {
      await api.createZone({ id: form.id, name: form.name, crop: form.crop, dry: Number(form.dry), wet: Number(form.wet) });
      setForm(blank);
      await actions.loadZones();
      actions.toast(`Zone ${form.id.toUpperCase()} created`);
    } catch (err) { setErrors({ ...(err.details || {}), _: err.message }); }
  }

  async function saveThresholds(zone, dry) {
    try { await api.updateZone(zone.id, { dry: Number(dry) }); await actions.loadZones(); actions.toast(`Zone ${zone.id} dry limit set to ${dry}%`); }
    catch (err) { actions.toast(err.message); }
  }

  async function remove(zone) {
    if (!window.confirm(`Delete ${zone.name} and all of its readings?`)) return;
    try { await api.deleteZone(zone.id); await actions.loadZones(); actions.toast(`${zone.name} deleted`); }
    catch (err) { actions.toast(err.message); }
  }

  return (
    <>
      <div className="grid zones">
        {state.zones.map((z) => (
          <div key={z.id} className="stack">
            <ZoneCard zone={z} reading={state.latest[z.id]} relay={state.relay[z.id]} />
            {isAdmin && (
              <form className="inline-form" onSubmit={(e) => { e.preventDefault(); saveThresholds(z, new FormData(e.currentTarget).get('dry')); }}>
                <label>Dry limit %<input name="dry" type="number" min="0" max="100" defaultValue={z.dry} /></label>
                <button className="btn">Save</button>
                <button type="button" className="btn danger" onClick={() => remove(z)}>Delete</button>
              </form>
            )}
          </div>
        ))}
      </div>

      {isAdmin ? (
        <section className="card" aria-labelledby="add-zone">
          <h2 id="add-zone">Add a growing zone</h2>
          <form onSubmit={add} className="form-grid" noValidate>
            <Field label="Zone ID (e.g. D)" value={form.id} onChange={set('id')} error={errors.id} maxLength={12} required />
            <Field label="Name" value={form.name} onChange={set('name')} error={errors.name} required />
            <Field label="Crop" value={form.crop} onChange={set('crop')} error={errors.crop} required />
            <Field label="Dry limit (%)" type="number" value={form.dry} onChange={set('dry')} error={errors.dry} />
            <Field label="Wet limit (%)" type="number" value={form.wet} onChange={set('wet')} error={errors.wet} />
            {errors._ && <p className="form-error" role="alert">{errors._}</p>}
            <button className="btn primary">Add zone</button>
          </form>
        </section>
      ) : <p className="muted">Viewer accounts are read-only. Sign in as admin to add or edit zones.</p>}
    </>
  );
}
