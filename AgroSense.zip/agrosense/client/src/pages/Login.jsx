import { useState } from 'react';
import { useApp } from '../context/AppContext';
import Field from '../components/Field';

/** Main (public) page: product intro + Login / Register with a username. Data is stored in PostgreSQL via the API. */
export default function Login() {
  const { actions } = useApp();
  const [mode, setMode] = useState('login');
  const [form, setForm] = useState({ username: '', email: '', password: '', confirm: '' });
  const [error, setError] = useState('');
  const [fields, setFields] = useState({});
  const [busy, setBusy] = useState(false);
  const set = (k) => (e) => setForm((f) => ({ ...f, [k]: e.target.value }));
  const isLogin = mode === 'login';

  function switchMode(next) { setMode(next); setError(''); setFields({}); }

  async function submit(e) {
    e.preventDefault();
    setError(''); setFields({});
    if (!isLogin && form.password !== form.confirm) { setFields({ confirm: 'does not match the password' }); return; }
    setBusy(true);
    try {
      if (isLogin) await actions.login(form.username, form.password);
      else await actions.register(form.username, form.email, form.password);
    } catch (err) {
      setError(err.message);
      setFields(err.details || {});
    } finally { setBusy(false); }
  }

  return (
    <div className="landing">
      <header className="landing-head">
        <p className="brand-line"><span className="brand-mark" aria-hidden="true">✿</span> agrosense</p>
        <a href="/fundamentals.html">HTML/CSS/JS demo</a>
      </header>

      <main className="landing-main">
        <section className="landing-intro" aria-labelledby="intro-title">
          <p className="eyebrow">SMART GREENHOUSE PLATFORM</p>
          <h1 id="intro-title">Monitor every zone. Water at the right moment.</h1>
          <p>Live soil moisture, temperature, humidity and light from your greenhouse, with alerts, automatic irrigation and AI insights.</p>
          <ul className="ticks">
            <li>Real-time dashboard (WebSocket + Server-Sent Events)</li>
            <li>REST API built with Node.js and Express</li>
            <li>All accounts and readings stored in PostgreSQL</li>
          </ul>
        </section>

        <section className="auth-card" aria-labelledby="auth-title">
          <div className="seg wide-seg" role="tablist" aria-label="Login or register">
            <button type="button" role="tab" aria-selected={isLogin} className={isLogin ? 'sel' : ''} onClick={() => switchMode('login')}>Login</button>
            <button type="button" role="tab" aria-selected={!isLogin} className={!isLogin ? 'sel' : ''} onClick={() => switchMode('register')}>Register</button>
          </div>
          <h2 id="auth-title">{isLogin ? 'Welcome back' : 'Create your account'}</h2>

          <form onSubmit={submit} noValidate>
            <Field label="Username" value={form.username} onChange={set('username')} error={fields.username}
              autoComplete="username" autoCapitalize="none" required
              placeholder={isLogin ? 'username or email' : '3–30 letters, numbers, _ . -'} />
            {!isLogin && <Field label="Email" type="email" value={form.email} onChange={set('email')} error={fields.email} autoComplete="email" required />}
            <Field label="Password" type="password" value={form.password} onChange={set('password')} error={fields.password}
              autoComplete={isLogin ? 'current-password' : 'new-password'} required placeholder={isLogin ? '' : 'at least 6 characters'} />
            {!isLogin && <Field label="Confirm password" type="password" value={form.confirm} onChange={set('confirm')} error={fields.confirm} autoComplete="new-password" required />}
            {error && <p className="form-error" role="alert">{error}</p>}
            <button className="btn primary wide" disabled={busy}>{busy ? 'Please wait…' : isLogin ? 'Login' : 'Create account'}</button>
          </form>

          {isLogin
            ? <p className="muted small">Demo admin: <code>admin</code> / <code>admin123</code>. New accounts are read-only viewers.</p>
            : <p className="muted small">Already registered? <button type="button" className="btn link" onClick={() => switchMode('login')}>Login</button></p>}
        </section>
      </main>
    </div>
  );
}
