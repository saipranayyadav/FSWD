import { useApp } from '../context/AppContext';
import { average, fmt } from '../lib/format';
import Kpi from '../components/Kpi';
import ZoneCard from '../components/ZoneCard';
import LiveChart from '../components/LiveChart';

export default function Overview() {
  const { state } = useApp();
  const vals = Object.values(state.latest);
  const avg = (k) => average(vals.map((v) => v[k]));

  return (
    <>
      <section className="hero" aria-labelledby="hero-title">
        <div>
          <p className="eyebrow">● LIVE GREENHOUSE SNAPSHOT</p>
          <h2 id="hero-title">Healthier crops start with better visibility.</h2>
          <p>{state.zones.length} zones reporting over WebSocket. Values below update the moment a sensor publishes.</p>
        </div>
      </section>

      <section aria-label="Greenhouse averages" className="kpi-grid">
        <Kpi label="Soil moisture" value={fmt(avg('soil'))} unit="%" note="Average of all zones" icon="◉" />
        <Kpi label="Air temperature" value={fmt(avg('temp'))} unit="°C" note="Average of all zones" icon="☼" />
        <Kpi label="Humidity" value={fmt(avg('humidity'), 0)} unit="%" note="Relative humidity" icon="≈" />
        <Kpi label="Light" value={fmt((avg('light') ?? 0) / 1000)} unit=" klux" note="Average light level" icon="☀" />
      </section>

      <section aria-labelledby="zones-title">
        <h2 id="zones-title" className="section-title">Growing zones</h2>
        <div className="grid zones">
          {state.zones.map((z) => <ZoneCard key={z.id} zone={z} reading={state.latest[z.id]} relay={state.relay[z.id]} />)}
        </div>
      </section>

      <LiveChart recent={state.recent} zones={state.zones} />
    </>
  );
}
