import { useApp } from '../context/AppContext';
import { useAsync } from '../hooks/useAsync';
import { api } from '../lib/api';

export default function Settings() {
  const { state } = useApp();
  const health = useAsync(() => fetch(`${api.base}/api/health`).then((r) => r.json()), []);

  return (
    <div className="grid two">
      <section className="card" aria-labelledby="acct">
        <h2 id="acct">Account</h2>
        <dl className="kv">
          <div><dt>Username</dt><dd>{state.user.username}</dd></div>
          <div><dt>Email</dt><dd>{state.user.email}</dd></div>
          <div><dt>Role</dt><dd>{state.user.role}</dd></div>
        </dl>
      </section>
      <section className="card" aria-labelledby="sys">
        <h2 id="sys">System</h2>
        <dl className="kv">
          <div><dt>Real-time link</dt><dd>{state.connection}</dd></div>
          <div><dt>API status</dt><dd>{health.data?.status ?? (health.loading ? '…' : 'unreachable')}</dd></div>
          <div><dt>Database</dt><dd>{health.data?.database ?? '–'}</dd></div>
          <div><dt>Server uptime</dt><dd>{health.data ? `${health.data.uptime}s` : '–'}</dd></div>
        </dl>
        <p className="muted small"><a href="/fundamentals.html">Open the plain HTML/CSS/JS page →</a></p>
      </section>
    </div>
  );
}
