import { useState } from 'react';
import { useApp } from '../context/AppContext';
import { api } from '../lib/api';
import { dateTime } from '../lib/format';

export default function Alerts() {
  const { state, dispatch, actions } = useApp();
  const isAdmin = state.user?.role === 'admin';
  const [onlyOpen, setOnlyOpen] = useState(false);
  const list = onlyOpen ? state.alerts.filter((a) => !a.acknowledged) : state.alerts;

  async function ack(id) {
    try { await api.ackAlert(id); dispatch({ type: 'alert-acked', ids: [id] }); }
    catch (err) { actions.toast(err.message); }
  }
  async function ackAll() {
    try { await api.ackAll(); dispatch({ type: 'alert-acked', ids: 'all' }); }
    catch (err) { actions.toast(err.message); }
  }

  return (
    <section className="card" aria-labelledby="alerts-title">
      <div className="row wrap">
        <div><h2 id="alerts-title">Alerts &amp; events</h2><p className="muted">{state.unacked} unacknowledged · new alerts arrive live via Server-Sent Events</p></div>
        <div className="controls">
          <label className="switch-row"><input type="checkbox" checked={onlyOpen} onChange={(e) => setOnlyOpen(e.target.checked)} /> Only unacknowledged</label>
          {isAdmin && <button type="button" className="btn" onClick={ackAll} disabled={!state.unacked}>Acknowledge all</button>}
        </div>
      </div>

      {list.length === 0 ? <p className="empty">All clear — no alerts to show.</p> : (
        <ul className="alert-list">
          {list.map((a) => (
            <li key={a.id} className={`alert-row ${a.level} ${a.acknowledged ? 'done' : ''}`}>
              <span className="alert-level">{a.level}</span>
              <div><p>{a.message}</p><p className="muted small"><time dateTime={new Date(a.time).toISOString()}>{dateTime(a.time)}</time>{a.zone && ` · Zone ${a.zone}`}</p></div>
              {a.acknowledged ? <span className="muted small">Acknowledged</span> : isAdmin && <button type="button" className="btn" onClick={() => ack(a.id)}>Acknowledge</button>}
            </li>
          ))}
        </ul>
      )}
    </section>
  );
}
