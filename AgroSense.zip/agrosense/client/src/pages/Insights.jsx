import { useAsync } from '../hooks/useAsync';
import { api } from '../lib/api';
import { dateTime } from '../lib/format';

export default function Insights() {
  const { data, error, loading, reload } = useAsync(() => api.insights(), []);

  return (
    <section className="card" aria-labelledby="ai-title">
      <div className="row wrap">
        <div><h2 id="ai-title">AI-assisted insights</h2><p className="muted">Built from the last 24 hours of database statistics.</p></div>
        <button type="button" className="btn" onClick={reload} disabled={loading}>{loading ? 'Thinking…' : 'Regenerate'}</button>
      </div>
      {error && <p className="form-error" role="alert">{error.message}</p>}
      {data && (
        <>
          <p><span className={`badge ${data.source === 'claude' ? 'good' : 'off'}`}>{data.source === 'claude' ? 'Written by Claude' : 'Rule-based'}</span> <span className="muted small">Generated {dateTime(data.generatedAt)}</span></p>
          {data.summary && <blockquote className="summary">{data.summary}</blockquote>}
          <ul className="alert-list">
            {data.recommendations.map((r, i) => (
              <li key={i} className={`alert-row ${r.level}`}><span className="alert-level">{r.level}</span><p>{r.text}</p></li>
            ))}
          </ul>
          {data.source === 'rules' && <p className="muted small">Set ANTHROPIC_API_KEY in server/.env to add a natural-language briefing from Claude.</p>}
        </>
      )}
    </section>
  );
}
