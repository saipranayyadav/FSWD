import type { Alert, AlertPage, HistoryPoint, Insights, IrrigationEvent, Reading, Relay, User, Zone, ZoneStats } from './types';

const BASE: string = (import.meta as any).env?.VITE_API_URL || '';
const TOKEN_KEY = 'agrosense.token';

export const tokenStore = {
  get: (): string | null => { try { return localStorage.getItem(TOKEN_KEY); } catch { return null; } },
  set: (t: string) => { try { localStorage.setItem(TOKEN_KEY, t); } catch { /* private mode */ } },
  clear: () => { try { localStorage.removeItem(TOKEN_KEY); } catch { /* private mode */ } },
};

export class ApiError extends Error {
  constructor(public status: number, message: string, public details?: Record<string, string>) { super(message); }
}

/** Single place that talks to fetch: adds JWT, parses JSON, converts failures into ApiError. */
async function request<T>(path: string, init: RequestInit = {}): Promise<T> {
  const token = tokenStore.get();
  const res = await fetch(`${BASE}${path}`, {
    ...init,
    headers: { 'Content-Type': 'application/json', ...(token ? { Authorization: `Bearer ${token}` } : {}), ...init.headers },
  });
  if (res.status === 204) return undefined as T;
  const body = await res.json().catch(() => ({}));
  if (!res.ok) throw new ApiError(res.status, body.error || res.statusText, body.details);
  return body as T;
}

const send = <T>(method: string, path: string, body?: unknown) => request<T>(path, { method, body: body === undefined ? undefined : JSON.stringify(body) });

export const api = {
  base: BASE,
  login: (username: string, password: string) => send<{ token: string; user: User }>('POST', '/api/auth/login', { username, password }),
  register: (username: string, email: string, password: string) => send<{ token: string; user: User }>('POST', '/api/auth/register', { username, email, password }),
  me: () => request<{ user: User }>('/api/auth/me'),

  zones: () => request<Zone[]>('/api/zones'),
  createZone: (z: { id: string; name: string; crop: string; dry?: number; wet?: number }) => send<Zone>('POST', '/api/zones', z),
  updateZone: (id: string, patch: Partial<Pick<Zone, 'name' | 'crop' | 'dry' | 'wet'>>) => send<Zone>('PATCH', `/api/zones/${id}`, patch),
  deleteZone: (id: string) => send<void>('DELETE', `/api/zones/${id}`),

  history: (zone: string, hours: number, bucket: number) => request<HistoryPoint[]>(`/api/history?zone=${zone}&hours=${hours}&bucket=${bucket}`),
  stats: (hours = 24) => request<ZoneStats[]>(`/api/stats?hours=${hours}`),
  addReading: (r: Omit<Reading, 'time'>) => send<Reading>('POST', '/api/readings', r),

  alerts: (limit = 50, unacknowledged = false) => request<AlertPage>(`/api/alerts?limit=${limit}&unacknowledged=${unacknowledged}`),
  ackAlert: (id: number) => send<Alert>('POST', `/api/alerts/${id}/ack`),
  ackAll: () => send<{ acknowledged: number }>('POST', '/api/alerts/ack-all'),

  setIrrigation: (zone: string, body: Partial<Relay>) => send<Relay>('POST', `/api/irrigation/${zone}`, body),
  irrigationEvents: (limit = 15) => request<IrrigationEvent[]>(`/api/irrigation/events?limit=${limit}`),

  insights: () => request<Insights>('/api/insights'),
};
