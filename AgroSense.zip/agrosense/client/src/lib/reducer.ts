// Application state is a single reducer (React useReducer) - predictable, testable, no extra library.
import type { Alert, Connection, Reading, RelayMap, User, Zone } from './types';

export interface State {
  user: User | null;
  booted: boolean;                 // finished checking the saved token
  zones: Zone[];
  latest: Record<string, Reading>; // newest reading per zone (live)
  relay: RelayMap;
  alerts: Alert[];
  unacked: number;
  connection: Connection;
  toast: string | null;
  recent: Record<string, Reading[]>; // short rolling window per zone for the live chart
}

export const initialState: State = {
  user: null, booted: false, zones: [], latest: {}, relay: {}, alerts: [], unacked: 0,
  connection: 'connecting', toast: null, recent: {},
};

export type Action =
  | { type: 'booted'; user: User | null }
  | { type: 'login'; user: User }
  | { type: 'logout' }
  | { type: 'zones'; zones: Zone[] }
  | { type: 'telemetry'; reading: Reading }
  | { type: 'relay'; relay: RelayMap }
  | { type: 'alerts'; alerts: Alert[]; unacked: number }
  | { type: 'alert-new'; alert: Alert }
  | { type: 'alert-acked'; ids: number[] | 'all' }
  | { type: 'connection'; connection: Connection }
  | { type: 'toast'; message: string | null };

const WINDOW = 60; // points kept per zone for the live chart

export function reducer(state: State, action: Action): State {
  switch (action.type) {
    case 'booted':
      return { ...state, booted: true, user: action.user };
    case 'login':
      return { ...state, user: action.user, booted: true };
    case 'logout':
      return { ...initialState, booted: true };
    case 'zones': {
      const latest = { ...state.latest };
      const relay: RelayMap = { ...state.relay };
      for (const z of action.zones) { if (z.latest && !latest[z.id]) latest[z.id] = z.latest; relay[z.id] = z.relay; }
      const ids = new Set(action.zones.map((z) => z.id));
      for (const id of Object.keys(latest)) if (!ids.has(id)) delete latest[id];
      return { ...state, zones: action.zones, latest, relay };
    }
    case 'telemetry': {
      const { reading } = action;
      const prev = state.recent[reading.zone] ?? [];
      return {
        ...state,
        latest: { ...state.latest, [reading.zone]: reading },
        recent: { ...state.recent, [reading.zone]: [...prev, reading].slice(-WINDOW) },
      };
    }
    case 'relay':
      return { ...state, relay: action.relay };
    case 'alerts':
      return { ...state, alerts: action.alerts, unacked: action.unacked };
    case 'alert-new':
      if (state.alerts.some((a) => a.id === action.alert.id)) return state;
      return { ...state, alerts: [action.alert, ...state.alerts].slice(0, 100), unacked: state.unacked + 1, toast: action.alert.message };
    case 'alert-acked': {
      const all = action.ids === 'all';
      const alerts = state.alerts.map((a) => (all || (action.ids as number[]).includes(a.id) ? { ...a, acknowledged: true } : a));
      return { ...state, alerts, unacked: alerts.filter((a) => !a.acknowledged).length };
    }
    case 'connection':
      return { ...state, connection: action.connection };
    case 'toast':
      return { ...state, toast: action.message };
    default:
      return state;
  }
}
