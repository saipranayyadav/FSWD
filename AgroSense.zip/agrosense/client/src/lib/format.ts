import type { HistoryPoint, Metric } from './types';

export const fmt = (n: number | null | undefined, digits = 1): string => (n === null || n === undefined ? '–' : Number(n).toFixed(digits));
export const clock = (t: number): string => new Date(t).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
export const dateTime = (t: number): string => new Date(t).toLocaleString([], { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' });

export const CROP_ICON: Record<string, string> = { tomato: '🍅', capsicum: '🫑', lettuce: '🥬', basil: '🌿' };
export const cropIcon = (crop: string): string => CROP_ICON[crop.toLowerCase()] ?? '🌱';

export type SoilStatus = { label: string; tone: 'bad' | 'warn' | 'good' | 'wet' | 'off' };
export function soilStatus(soil: number | undefined, dry: number): SoilStatus {
  if (soil === undefined) return { label: 'Waiting', tone: 'off' };
  if (soil < dry * 0.8) return { label: 'Critical', tone: 'bad' };
  if (soil < dry) return { label: 'Needs water', tone: 'warn' };
  if (soil > 70) return { label: 'Saturated', tone: 'wet' };
  return { label: 'Healthy', tone: 'good' };
}

/** Pivot flat rows [{t, zone, soil...}] into chart rows [{t, A: 55, B: 48}] for one metric. */
export function pivotHistory(points: HistoryPoint[], metric: Metric): Record<string, number>[] {
  const rows = new Map<number, Record<string, number>>();
  for (const p of points) {
    const row = rows.get(p.t) ?? { t: p.t };
    row[p.zone] = p[metric];
    rows.set(p.t, row);
  }
  return [...rows.values()].sort((a, b) => a.t - b.t);
}

export const METRICS: Record<Metric, { label: string; unit: string }> = {
  soil: { label: 'Soil moisture', unit: '%' },
  temp: { label: 'Temperature', unit: '°C' },
  humidity: { label: 'Humidity', unit: '%' },
  light: { label: 'Light', unit: ' lux' },
};

export const average = (xs: number[]): number | null => (xs.length ? xs.reduce((s, x) => s + x, 0) / xs.length : null);

/** Merge per-zone rolling windows into chart rows. Readings that arrive in the same 2s tick share a row. */
export function pivotLive(recent: Record<string, { time: number; soil: number; temp: number; humidity: number; light: number }[]>, metric: Metric): Record<string, number>[] {
  const rows = new Map<number, Record<string, number>>();
  for (const [zone, list] of Object.entries(recent)) {
    for (const r of list) {
      const key = Math.round(r.time / 2000);
      const row = rows.get(key) ?? { t: r.time };
      row[zone] = r[metric];
      rows.set(key, row);
    }
  }
  return [...rows.entries()].sort((a, b) => a[0] - b[0]).map(([, v]) => v);
}

export const ZONE_COLORS = ['#3f9a5f', '#2f86b5', '#d29a1f', '#c4564a', '#7a5bb5', '#2a9d8f'];
export const zoneColor = (ids: string[], id: string): string => ZONE_COLORS[Math.max(0, ids.indexOf(id)) % ZONE_COLORS.length];
