export type Role = 'admin' | 'viewer';
export interface User { id: number; username: string; email: string; name: string; role: Role }

export interface Relay { on: boolean; auto: boolean }
export type RelayMap = Record<string, Relay>;

export interface Reading { time: number; zone: string; soil: number; temp: number; humidity: number; light: number }
export interface Zone {
  id: string; name: string; crop: string; dry: number; wet: number;
  relay: Relay; latest: Reading | null;
}

export type AlertLevel = 'info' | 'warning' | 'critical';
export interface Alert { id: number; time: number; zone: string | null; level: AlertLevel; message: string; acknowledged: boolean }
export interface AlertPage { items: Alert[]; total: number }

export interface HistoryPoint { t: number; zone: string; soil: number; temp: number; humidity: number; light: number }
export type Metric = 'soil' | 'temp' | 'humidity' | 'light';

export interface ZoneStats {
  zone: string; name: string; crop: string; samples: number;
  soil: { avg: number; min: number; max: number };
  temp: { avg: number; min: number; max: number };
  humidity: number; light: number;
}

export interface IrrigationEvent { id: number; time: number; zone: string; action: 'start' | 'stop'; source: 'manual' | 'auto'; user: string | null }
export interface Insights {
  source: 'rules' | 'claude'; generatedAt: number; summary: string | null;
  recommendations: { zone: string | null; level: AlertLevel; text: string }[];
}

export type Connection = 'connecting' | 'live' | 'offline';
