import { Navigate, Route, Routes } from 'react-router-dom';
import Layout from './components/Layout';
import ProtectedRoute from './components/ProtectedRoute';
import { useApp } from './context/AppContext';
import Login from './pages/Login';
import Overview from './pages/Overview';
import Zones from './pages/Zones';
import Climate from './pages/Climate';
import Irrigation from './pages/Irrigation';
import Alerts from './pages/Alerts';
import SensorInput from './pages/SensorInput';
import Insights from './pages/Insights';
import Settings from './pages/Settings';

export default function App() {
  const { state } = useApp();
  return (
    <Routes>
      <Route path="/login" element={state.user ? <Navigate to="/" replace /> : <Login />} />
      <Route element={<ProtectedRoute><Layout /></ProtectedRoute>}>
        <Route index element={<Overview />} />
        <Route path="zones" element={<Zones />} />
        <Route path="climate" element={<Climate />} />
        <Route path="irrigation" element={<Irrigation />} />
        <Route path="alerts" element={<Alerts />} />
        <Route path="sensors" element={<SensorInput />} />
        <Route path="insights" element={<Insights />} />
        <Route path="settings" element={<Settings />} />
      </Route>
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}
