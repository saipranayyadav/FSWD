import { Navigate } from 'react-router-dom';
import { useApp } from '../context/AppContext';

export default function ProtectedRoute({ children }) {
  const { state } = useApp();
  if (!state.booted) return <p className="boot" role="status">Loading…</p>;
  return state.user ? children : <Navigate to="/login" replace />;
}
