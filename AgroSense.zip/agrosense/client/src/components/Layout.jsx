import { NavLink, Outlet, useLocation } from 'react-router-dom';
import { useApp } from '../context/AppContext';
import Toast from './Toast';

const NAV = [
  ['/', 'Overview', '⌂'],
  ['/zones', 'Growing zones', '♧'],
  ['/climate', 'Climate & trends', '≈'],
  ['/irrigation', 'Irrigation', '◉'],
  ['/alerts', 'Alerts', '⚑'],
  ['/sensors', 'Sensor input', '✎'],
  ['/insights', 'AI insights', '✦'],
  ['/settings', 'Settings', '⚙'],
];

const LABEL = { live: 'Live', connecting: 'Connecting', offline: 'Offline' };

export default function Layout() {
  const { state, actions } = useApp();
  const { pathname } = useLocation();
  const title = (NAV.find(([to]) => to === pathname) || NAV[0])[1];

  return (
    <div className="shell">
      <a className="skip-link" href="#main">Skip to main content</a>

      <aside className="sidebar" aria-label="Primary">
        <div className="brand"><span className="brand-mark" aria-hidden="true">✿</span><span>agrosense<small>GROW WITH INSIGHT</small></span></div>
        <nav aria-label="Main navigation">
          <ul>
            {NAV.map(([to, label, icon]) => (
              <li key={to}>
                <NavLink to={to} end={to === '/'} className={({ isActive }) => (isActive ? 'active' : undefined)}>
                  <span aria-hidden="true">{icon}</span>{label}
                  {to === '/alerts' && state.unacked > 0 && <b className="count" aria-label={`${state.unacked} unacknowledged`}>{state.unacked}</b>}
                </NavLink>
              </li>
            ))}
          </ul>
        </nav>
      </aside>

      <div className="column">
        <header className="topbar">
          <h1>{title}</h1>
          <div className="top-actions">
            <span className={`pill ${state.connection}`} role="status"><i aria-hidden="true" />{LABEL[state.connection]}</span>
            <span className="user-chip">{state.user?.username} <small>({state.user?.role})</small></span>
            <button type="button" className="btn ghost" onClick={actions.logout}>Log out</button>
          </div>
        </header>

        <main id="main" className="content" tabIndex={-1}>
          <Outlet />
        </main>

        <footer className="footer">© 2026 AgroSense · Greenhouse intelligence · React + Express + PostgreSQL</footer>
      </div>

      <Toast />
    </div>
  );
}
