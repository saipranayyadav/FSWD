import { useEffect } from 'react';
import { useApp } from '../context/AppContext';

export default function Toast() {
  const { state, dispatch } = useApp();
  useEffect(() => {
    if (!state.toast) return undefined;
    const t = setTimeout(() => dispatch({ type: 'toast', message: null }), 4000);
    return () => clearTimeout(t);
  }, [state.toast, dispatch]);

  return (
    <div className="toast-region" role="status" aria-live="polite">
      {state.toast && (
        <p className="toast">
          <span>{state.toast}</span>
          <button type="button" aria-label="Dismiss notification" onClick={() => dispatch({ type: 'toast', message: null })}>×</button>
        </p>
      )}
    </div>
  );
}
