import { useMemo, useState } from 'react';
import { CartesianGrid, Legend, Line, LineChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';
import { METRICS, clock, pivotLive, zoneColor } from '../lib/format';

/** Streaming chart: appends every WebSocket reading the reducer receives. */
export default function LiveChart({ recent, zones }) {
  const [metric, setMetric] = useState('soil');
  const ids = zones.map((z) => z.id);
  const data = useMemo(() => pivotLive(recent, metric), [recent, metric]);

  return (
    <section className="card" aria-labelledby="live-title">
      <div className="row">
        <h2 id="live-title">Live feed</h2>
        <label className="inline">Metric
          <select value={metric} onChange={(e) => setMetric(e.target.value)}>
            {Object.entries(METRICS).map(([k, m]) => <option key={k} value={k}>{m.label}</option>)}
          </select>
        </label>
      </div>
      {data.length < 2 ? <p className="empty">Waiting for live readings…</p> : (
        <div className="chart-box" role="img" aria-label={`Live ${METRICS[metric].label} for each zone`}>
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={data} margin={{ left: -10, right: 8, top: 8 }}>
              <CartesianGrid stroke="var(--line)" vertical={false} />
              <XAxis dataKey="t" tickFormatter={clock} minTickGap={50} tick={{ fontSize: 11 }} />
              <YAxis domain={['auto', 'auto']} tick={{ fontSize: 11 }} />
              <Tooltip labelFormatter={clock} />
              <Legend />
              {zones.map((z) => (
                <Line key={z.id} name={`${z.crop} (${z.id})`} dataKey={z.id} stroke={zoneColor(ids, z.id)} strokeWidth={2} dot={false} isAnimationActive={false} connectNulls />
              ))}
            </LineChart>
          </ResponsiveContainer>
        </div>
      )}
    </section>
  );
}
