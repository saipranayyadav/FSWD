import { useId } from 'react';

/** Accessible labelled input with an optional server-side validation message. */
export default function Field({ label, error, ...input }) {
  const id = useId();
  return (
    <div className="field">
      <label htmlFor={id}>{label}</label>
      <input id={id} aria-invalid={!!error} aria-describedby={error ? `${id}-err` : undefined} {...input} />
      {error && <p id={`${id}-err`} className="field-error">{error}</p>}
    </div>
  );
}
