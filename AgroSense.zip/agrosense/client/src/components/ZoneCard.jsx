import { cropIcon, fmt, soilStatus } from '../lib/format';

export default function ZoneCard({ zone, reading, relay }) {
  const s = soilStatus(reading?.soil, zone.dry);
  const soil = reading?.soil ?? 0;
  return (
    <article className="card zone-card" aria-labelledby={`zone-${zone.id}`}>
      <header className="zone-head">
        <span className="crop-avatar" aria-hidden="true">{cropIcon(zone.crop)}</span>
        <div>
          <h3 id={`zone-${zone.id}`}>{zone.crop}</h3>
          <p className="muted">{zone.name} · Zone {zone.id}</p>
        </div>
        <span className={`badge ${s.tone}`}>{s.label}</span>
      </header>

      <p className="big-number">{fmt(reading?.soil)}<small>% soil moisture</small></p>
      <div className="meter" role="meter" aria-valuenow={soil} aria-valuemin="0" aria-valuemax="100" aria-label={`Soil moisture in zone ${zone.id}`}>
        <div className={`meter-fill ${s.tone}`} style={{ width: `${Math.min(soil, 100)}%` }} />
        <div className="meter-mark" style={{ left: `${zone.dry}%` }} title={`Dry limit ${zone.dry}%`} />
      </div>

      <dl className="stats">
        <div><dt>Temp</dt><dd>{fmt(reading?.temp)}°C</dd></div>
        <div><dt>Humidity</dt><dd>{fmt(reading?.humidity, 0)}%</dd></div>
        <div><dt>Light</dt><dd>{reading ? fmt(reading.light / 1000) : '–'} k</dd></div>
      </dl>
      <p className="muted small">Irrigation: <strong>{relay?.on ? 'running' : 'standby'}</strong> · {relay?.auto ? 'automatic' : 'manual'}</p>
    </article>
  );
}
