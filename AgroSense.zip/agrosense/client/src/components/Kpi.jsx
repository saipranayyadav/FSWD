export default function Kpi({ label, value, unit, note, icon }) {
  return (
    <article className="kpi">
      <span className="kpi-icon" aria-hidden="true">{icon}</span>
      <h3>{label}</h3>
      <p className="kpi-value">{value}<small>{unit}</small></p>
      <p className="muted">{note}</p>
    </article>
  );
}
