// Plain JavaScript (no framework): DOM manipulation + the three async styles.
'use strict';

const $ = (sel) => document.querySelector(sel);
const API = ''; // same origin (Vite proxy in dev, Express in production)

// ---------- DOM manipulation ----------
function renderSummary(data) {
  const cards = $('#cards');
  cards.replaceChildren(); // clear old content

  const make = (title, value, unit) => {
    const article = document.createElement('article');
    const h3 = document.createElement('h3');
    const p = document.createElement('p');
    h3.textContent = title;
    p.textContent = value === null ? '–' : `${value}${unit}`;
    article.append(h3, p);
    return article;
  };

  cards.append(
    make('Zones', data.zones, ''),
    make('Soil moisture', data.average.soil, '%'),
    make('Temperature', data.average.temp, '°C'),
    make('Humidity', data.average.humidity, '%'),
  );
  data.crops.forEach((c) => cards.append(make(`${c.crop} (zone ${c.id})`, c.soil, '%')));
}

// ---------- async/await with error handling ----------
async function loadSummary() {
  $('#status').textContent = 'Loading…';
  try {
    const res = await fetch(`${API}/api/public/summary`);
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    renderSummary(await res.json());
    $('#status').textContent = `Updated ${new Date().toLocaleTimeString()}`;
  } catch (err) {
    $('#status').textContent = `Could not reach the API (${err.message}). Is the server running?`;
  }
}

// ---------- three ways to receive the same result ----------
function log(message) {
  const li = document.createElement('li');
  li.textContent = `${new Date().toLocaleTimeString()}  ${message}`;
  $('#log').prepend(li);
}

function viaCallback() {
  const xhr = new XMLHttpRequest();
  xhr.open('GET', `${API}/api/health`);
  xhr.onload = () => log(`callback  -> ${xhr.status} ${xhr.responseText}`);
  xhr.onerror = () => log('callback  -> network error');
  xhr.send();
  log('callback  -> request sent, doing other work meanwhile');
}

function viaPromise() {
  fetch(`${API}/api/health`)
    .then((res) => res.json())
    .then((data) => log(`promise   -> ${JSON.stringify(data)}`))
    .catch((err) => log(`promise   -> ${err.message}`));
  log('promise   -> request sent, .then() runs later');
}

async function viaAwait() {
  log('await     -> request sent, function pauses here');
  try {
    const data = await (await fetch(`${API}/api/health`)).json();
    log(`await     -> ${JSON.stringify(data)}`);
  } catch (err) {
    log(`await     -> ${err.message}`);
  }
}

const handlers = { callback: viaCallback, promise: viaPromise, await: viaAwait };

// ---------- event handling (delegation) ----------
document.addEventListener('click', (event) => {
  const btn = event.target.closest('button[data-style]');
  if (btn) handlers[btn.dataset.style]();
});
$('#refresh').addEventListener('click', loadSummary);

loadSummary();
setInterval(loadSummary, 5000);
