#!/usr/bin/env bash
# macOS / Linux launcher: installs dependencies if needed and starts API + web app.
set -e
cd "$(dirname "$0")"
[ -f server/.env ] || cp server/.env.example server/.env
[ -d server/node_modules ] || npm --prefix server install
[ -d client/node_modules ] || npm --prefix client install
trap 'kill 0' EXIT
npm --prefix server run dev &
npm --prefix client run dev &
echo "Open http://localhost:5173  (admin / admin123)"
wait
