@echo off
setlocal
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo Node.js is not installed or not on PATH.
  echo Install the LTS version from https://nodejs.org/ and reopen this file.
  pause
  exit /b 1
)
if not exist "server\.env" (
  copy "server\.env.example" "server\.env" >nul
  echo Created server\.env  [embedded PostgreSQL + simulator mode]
)
echo Starting AgroSense API and web app in separate windows...
start "AgroSense API" cmd /k "cd /d "%~dp0server" && if not exist node_modules npm install && npm run dev"
start "AgroSense Web" cmd /k "cd /d "%~dp0client" && if not exist node_modules npm install && npm run dev"
echo.
echo Wait for both windows to finish installing, then open http://localhost:5173
echo Login: admin  /  admin123
pause
